<?php 
class Reserve{
public $ReserveID;
public $ReserveName;
public $ReserveTel;
public $ReserveEmail;
public $TimeID;
public $BadmintonID;

public function Reserve($ReserveID,$ReserveName,$ReserveTel,$ReserveEmail,$TimeID,$BadmintonID)
{
	
	$this->ReserveID = $ReserveID;
    $this->ReserveName = $ReserveName;
	$this->ReserveTel = $ReserveTel;
	$this->ReserveEmail = $ReserveEmail;
	$this->TimeID = $TimeID;
	$this->BadmintonID = $BadmintonID;
}


public static function get($ID)
{
  require("connection_connect.php");
  $sql = "select Reserve.ReserveID, Reserve.ReserveName, Reserve.ReserveTel, Reserve.ReserveEmail, Reserve.TimeID, Reserve.BadmintonID
  from Reserve,Badminton,Time 
  where ReserveID='$ID' AND Reserve.TimeID=Time.TimeID AND Reserve.BadmintonID=Badminton.BadmintonID";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $ReserveID=$my_row['ReserveID'];
  $ReserveName=$my_row['ReserveName'];
  $ReserveTel=$my_row['ReserveTel'];
  $ResreveEmail=$my_row['ReserveEmail'];
  $TimeID=$my_row['TimeID'];
  $BadmintonID=$my_row['BadmintonID'];
  require("connection_close.php");

  return new Reserve($ReserveID,$ReserveName,$ReserveTel,$ReserveEmail,$TimeID,$BadmintonID);
}

public static function getAll()
{
  $ReserveList=[];
  require("connection_connect.php");
  $sql = "SELECT * FROM Reserve";
  $result=$conn->query($sql);
  while($my_row = $result->fetch_assoc())
{
  $ReserveID=$my_row['ReserveID'];
  $ReserveName=$my_row['ReserveName'];
  $ReserveTel=$my_row['ReserveTel'];
  $ReserveEmail=$my_row['ReserveEmail'];
  $TimeID=$my_row['TimeID'];
  $BadmintonID=$my_row['BadmintonID'];
  $ReserveList[]= new Reserve($ReserveID,$ReserveName,$ReserveTel,$ReserveEmail,$TimeID,$BadmintonID);
}
require("connection_close.php");
return $ReserveList;
}

/*public static function search($key)
{	require("connection_connect.php");
    $sql = "select Reserve.ReserveID, Reserve.ReserveName, Reserve.ReserveTel, Reserve.ReserveEmail, Reserve.TimeID, Reserve.BadmintonID
    from Reserve,Badminton,Time 
    where (ReserveID like'%$key%' or ReserveName like'%$key%' or ReserveTel like'%$key%' or ReserveEmail like'%$key%' or TimeID like'%$key%' or BadmintonID like'%$key%')
    AND Reserve.TimeID=Time.TimeID AND Reserve.BadmintonID=Badminton.BadmintonID";
    $result=$conn->query($sql);
	while($my_row = $result->fetch_assoc())
	{
		$ReserveID=$my_row['ReserveID'];
        $ReserveName=$my_row['ReserveName'];
        $ReserveTel=$my_row['ReserveTel'];
        $ResreveEmail=$my_row['ReserveEmail'];
        $TimeID=$my_row['TimeID'];
        $BadmintonID=$my_row['BadmintonID'];
		$ReserveList[]= new Reserve($ReserveID,$ReserveName,$ReserveTel,$ReserveEmail,$TimeID,$BadmintonID);
	}
		require("connection_close.php");
		return $ReserveList;
}

public static function add($ReserveID,$ReserveName,$ReserveTel,$ReserveEmail,$TimeID,$BadmintonID)
{	require("connection_connect.php");
    $sql = "insert into Reserve(ReserveID,ReserveName,ReserveTel,ReserveEmail,TimeID,BadmintonID)
    values ('$ReserveID','$ReserveName','$ReserveTel','$ReserveEmail','$TimeID','$BadmintonID')";
    $result=$conn->query($sql);
	require("connection_close.php");
	return "add success $result rows";}

public static function update($ReserveID,$ReserveName,$ReserveTel,$ReserveEmail,$TimeID,$BadmintonID)
{	require("connection_connect.php");
    $sql = "update Reserve set ReserveName='$ReserveName',ReserveTel='$ReserveTel',ReserveEmail='$ReserveEmail',TimeID='$TimeID',BadmintonID='$BadmintonID'
    where Reserve.ReserveID='$ReserveID' ";
    $result=$conn->query($sql);
	require("connection_close.php");
	return "update success $result rows";}

public static function delete($ID)
{	require("connection_connect.php");
	$sql = "Delete from Reserve Where Reserve.ReserveID='$ID'";
    $result=$conn->query($sql);
	require("connection_close.php");
    return "delete success $result rows";
}*/
}




