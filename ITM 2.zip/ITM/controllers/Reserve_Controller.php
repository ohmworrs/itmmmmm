<?php 
class ReserveController
{	public function index()
	{	$ReserveList= Reserve::getAll();
		require_once('views/Reserve/index_reserve.php');
	}

	public function newReserve()
	{
		$TimeList=Time::getAll();
		require_once("views/Reserve/newReserve.php");
		$BadmintonList=Badminton::getAll();
		require_once("views/Reserve/newReserve.php");

	}
}?>