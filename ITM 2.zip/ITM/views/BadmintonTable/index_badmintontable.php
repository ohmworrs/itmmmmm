<table border=1>
	<tr> <td>BadmintonID</td><td>BadmintonCourt</td><td>TerminalGym</td><td>TimeStart</td>
		<td>TimeFinish</td><td>Status</td></tr>


<?php foreach($BadmintonTableList as $Badminton)
{
	
	echo "
			<td>$Badminton->BadmintonID </td>
			<td>$Badminton->BadmintonCourt </td>
			<td>$Badminton->TerminalGym </td>
			<td>$Badminton->TimeStart </td>
			<td>$Badminton->TimeFinish </td>
			<td>$Badminton->StatusCourt  </td></tr>";
			

			


			
}
	echo "</table>";

	
	
?>

	

