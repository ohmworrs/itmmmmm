<html>
<head></head>
<body>
<form method="get" action="">
<label>ชื่อผู้จอง <input type="text" name="ReserveName" /> </label><br>
<label>เบอร์โทร <input type="text" name="ReserveTel" /> </label><br>
<label>อีเมลล์<input type="text" name="ReserveEmail" /> </label><br>
<label>ช่วงเวลาเริ่ม <select name="TimeID" > 
    <?php foreach($TimeList as $Time)
    {
        echo "<option value = $Time->TimeID>$Time->TimeID</option>";
    }?>
     </select></label><br>
<label>BadmintonID <select name="BadmintonID"> 
    <?php foreach($BadmintonList as $Badminton)
    {
        echo "<option value = $Badminton->BadmintonID>$Badminton->BadmintonCourt</option>";
    }?>
     </select></label><br>



</body>
</html>




