<?php 
class ReserveController
{	
	public function index()
	{	$ReserveList= Reserve::getAll();
		require_once('views/Reserve/index_reserve.php');
	}

	public function newReserve()
	{
		$TimeList=Time::getAll();
		$BadmintonList=Badminton::getAll();
		require_once("views/Reserve/newReserve.php");
		
	}
	public function addReserve()
	{
		$ReserveName=$_GET['ReserveName'];
		$ReserveTel=$_GET['ReserveTel'];
		$ReserveEmail=$_GET['ReserveEmail'];
		$TypePerson = $_GET['TypePerson'];
		$BadmintonCourt=$_GET['BadmintonCourt'];
		$TerminalGym=$_GET['TerminalGym'];
		$TimeStart=$_GET['TimeStart'];
		$TimeFinish=$_GET['TimeFinish'];
		$BadmintonID=$_GET['BadmintonID'];
		
		Reserve::Add($ReserveName,$ReserveTel,$ReserveEmail,$TypePerson,$BadmintonCourt,$TerminalGym,$TimeStart,$TimeFinish,$BadmintonID);
		ReserveController::index();
	
	}

	public function deleteConfirm()
	{
		$ReserveID=$_GET['ReserveID'];
		$Reserve=Reserve::get($ReserveID);
		require_once('views/Reserve/deleteConfirm.php');
	}

	public function delete()
	{
			$ReserveID=$_GET['ReserveID'];
			Reserve::delete($ReserveID);
			ReserveController::index();
	}

	public function search()
	{
		
		$key=$_GET['key'];
		$ReserveList=Reserve::search($key);	
		require_once('views/Reserve/index_reserve.php');
	}




}?>