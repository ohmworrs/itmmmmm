<?php 
class MemberBadmintonController
{
	public function index()
	{
		$MemberBadmintonList=MemberBadminton::getAll();
		require_once('views/MemberBadminton/index_memberbadminton.php');
	}

	public function newMemberBadminton()
	{
		$MemberBadmintonList=MemberBadminton::getAll();
		require_once('views/MemberBadminton/newMemberBadminton.php');

	}

	public function addMemberBadminton()
	{
		$MemberBadmintonID=$_GET['MemberBadmintonID'];
		$MemberName=$_GET['MemberName'];
		$MemberAddress=$_GET['MemberAddress'];
		$MemberTel=$_GET['MemberTel'];
		$MemberEmail=$_GET['MemberEmail'];
		$TypeMember=$_GET['TypeMember'];
		MemberBadminton::Add($MemberBadmintonID,$MemberName, $MemberAddress, $MemberTel, $MemberEmail ,$TypeMember);
		MemberBadmintonController::index();
	}

	public function search()
	{
		$key=$_GET['key'];
		$MemberBadmintonList=MemberBadminton::search($key);
		require_once('views/MemberBadminton/index_memberbadminton.php');
	}

	public function update()
	{
		//error_reporting(~E_NOTICE);
		$MemberBadmintonID=$_GET['MemberBadmintonID'];
		$MemberName=$_GET['MemberName'];
		$MemberAddress=$_GET['MemberAddress'];
		$MemberTel=$_GET['MemberTel'];
		$MemberEmail=$_GET['MemberEmail'];
		$TypeMember=$_GET['TypeMember'];
		MemberBadminton::update($MemberBadmintonID,$MemberName, $MemberAddress, $MemberTel, $MemberEmail ,$TypeMember);
		MemberBadmintonController::index();
	}

	public function updateForm()
	{
		$MemberBadmintonID=$_GET['MemberBadmintonID'];
		$MemberBadminton = MemberBadminton::get($MemberBadmintonID);
		$MemberBadmintonList=MemberBadminton::getAll();
		require_once('views/MemberBadminton/updateForm.php');
	}

	public function deleteConfirm()
	{
		$MemberBadmintonID=$_GET['MemberBadmintonID'];
		$MemberBadminton=MemberBadminton::get($MemberBadmintonID);
		require_once('views/MemberBadminton/deleteConfirm.php');

	}

	public function delete()
	{
		
		$MemberBadmintonID=$_GET['MemberBadmintonID'];
		MemberBadminton::delete($MemberBadmintonID);
		MemberBadmintonController::index();
	}

}?>