<?php class GymController
{
	public function index()
	{
		$GymList=Gym::getAll();
		require_once('views/Gym/index_gym.php');
	}
	public function newGym()
	{
		$GymList=Gym::getAll();
		require_once('views/Gym/newGym.php');
	}
	public function addGym()
	{
		$GymID=$_GET['GymID'];
		$GymName=$_GET['GymName'];

		Gym::Add($GymID,$GymName);
		GymController::index();

	}

	public function search()
	{
		$key=$_GET['key'];
		$GymList=Gym::search($key);
		require_once('views/Gym/index_gym.php');
	}
	public function updateForm()
	{
		$GymID=$_GET['GymID'];
		$Gym=Gym::get($GymID);
		$GymList=Gym::getAll();
		require_once('views/Gym/updateForm.php');
	}
	public function update()
	{
		$GymID=$_GET['GymID'];
		$GymName=$_GET['GymName'];

		Gym::update($GymID,$GymName);
		GymController::index();
	}
	public function deleteConfirm()
	{
		$GymID=$_GET['GymID'];
		$Gym=Gym::get($GymID);
		require_once('views/Gym/deleteConfirm.php');
	}
	public function delete()
	{
			$GymID=$_GET['GymID'];
			Gym::delete($GymID);
			GymController::index();
	}



}?>