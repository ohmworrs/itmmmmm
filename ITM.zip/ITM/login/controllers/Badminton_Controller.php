<?php class BadmintonController
{
	public function index(){
		$BadmintonList = Badminton::getAll();
		require_once('views/Badminton/index_badminton.php');
	}
	public function newBadminton()
	{
		$TimeList=Time::getAll();
		$GymList=Gym::getAll();
		
		require_once("views/Badminton/newBadminton.php");
		
	}
	public function addBadminton()
	{
		$BadmintonID=$_GET['BadmintonID'];
		$BadmintonCourt=$_GET['BadmintonCourt'];
		$StatusCourt=$_GET['StatusCourt'];
		$GymID=$_GET['GymID'];
		$TimeID=$_GET['TimeID'];
		Badminton::Add($BadmintonID,$BadmintonCourt,$StatusCourt,$GymID,$TimeID);
		BadmintonController::index();
	}

	public function search()
	{
		$key=$_GET['key'];
		$BadmintonList=Badminton::search($key);
		require_once('views/Badminton/index_badminton.php');
	}

	public function updateForm()
	{
		$BadmintonID=$_GET['BadmintonID'];
		$Badminton=Badminton::get($BadmintonID);
		//$BadmintonList=Badminton::getAll();
		$TimeList=Time::getAll();
		$GymList=Gym::getAll();
		require_once('views/Badminton/updateForm.php');
	}

	public function update()
	{
		//error_reporting(~E_NOTICE);
		$BadmintonID=$_GET['BadmintonID'];
		$BadmintonCourt=$_GET['BadmintonCourt'];
		$StatusCourt=$_GET['StatusCourt'];
		$GymID=$_GET['GymID'];
		$TimeID=$_GET['TimeID'];
		Badminton::update($BadmintonID,$BadmintonCourt,$StatusCourt,$GymID,$TimeID);
		BadmintonController::index();
	}

	public function delete()
	{
		
		$BadmintonID=$_GET['BadmintonID'];
		Badminton::delete($BadmintonID);
		BadmintonController::index();
	}

	public function deleteConfirm()
	{
		$BadmintonID=$_GET['BadmintonID'];
		$Badminton=Badminton::get($BadmintonID);
		require_once('views/Badminton/deleteConfirm.php');

	}





}?>