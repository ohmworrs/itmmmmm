<?php 
class RateBadmintonController
{
	public function index()
	{
		$RateBadmintonList=RateBadminton::getAll();
		require_once('views/RateBadminton/index_ratebadminton.php');
	}

	public function newRateBadminton()
	{
		$RateBadmintonList=RateBadminton::getAll();
		require_once('views/RateBadminton/newRateBadminton.php');

	}

	public function addRateBadminton()
	{
		$RateBadmintonID=$_GET['RateBadmintonID'];
		$TypeRatePerson=$_GET['TypeRatePerson'];
		$TerminalGym=$_GET['TerminalGym'];
		$PriceMemberPerYear=$_GET['PriceMemberPerYear'];
		$PriceMember=$_GET['PriceMember'];
		$PriceNotMember=$_GET['PriceNotMember'];
		RateBadminton::Add($RateBadmintonID,$TypeRatePerson, $TerminalGym, $PriceMemberPerYear, $PriceMember ,$PriceNotMember);
		RateBadmintonController::index();
	}
}?>