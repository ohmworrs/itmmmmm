

<?php session_start(); 
require_once("connection_connect.php");
 
  $ID = $_SESSION['ID'];
  $name = $_SESSION['name'];
  $level = $_SESSION['level'];
 	if($level!='admin'){
    Header("Location: ../logout.php");  
  } 
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="logout.php">
	<h1>Admin Page</h1>
	<h3> สวัสดี คุณ <?php echo $name; ?> สถานะ <?php echo $level; ?> </h3>
	<input type="submit" value="logout">

	</form>
	<?php

//error_reporting (E_ALL ^ E_NOTICE);	

if (isset($_GET['controller'])&&isset($_GET['action']))
{
	$controller = $_GET['controller'];
	$action = $_GET['action'];
}
else 
{
	$controller = 'pages';
	$action = 'home';
}?>
<?php echo "controller=".$controller.",action=".$action;?>
	<br>
	
	<center>
	[<a href="./index.php">Home</a>]
	[<a href="./?controller=BadmintonTable&action=index">ตารางแบดมินตัน</a>]
	[<a href="./?controller=RateBadminton&action=index">อัตราการใช้บริการ</a>]<br>
	[<a href="./?controller=Time&action=index">จัดการเวลา</a>]
  	[<a href="./?controller=Gym&action=index">จัดการอาคาร</a>]
  	[<a href="./?controller=Badminton&action=index">จัดการการสนาม</a>]<br>
	[<a href="./?controller=Reserve&action=index">จัดการการการจอง</a>]
	

	
	
		<br>
</body>
<?php 
		require_once("routes.php"); ?>
		

</html>


	 

