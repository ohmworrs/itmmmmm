<?php class Gym{
	public $GymID,$GymName;
	public function Gym($GymID,$GymName)
	{
		$this->GymID = $GymID;
		$this->GymName = $GymName;
		
	}
	public static function getAll()
	{
		$GymList=[];
		require("connection_connect.php");
		$sql="select * from Gym";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
			$GymID=$my_row['GymID'];
			$GymName=$my_row['GymName'];
			
			$GymList[]=new Gym($GymID,$GymName);
		}
		require("connection_close.php");
		return $GymList;
			
	}
	public static function add($GymID,$GymName)
	{
		require("connection_connect.php");
		$sql="insert into Gym (GymID,GymName)
		values('$GymID','$GymName')";
		$result=$conn->query($sql);
		require("connection_close.php");
		return "add success $result rows";
	}
	

	public static function search($key)
	{
		$GymList=[];
		require("connection_connect.php");
		$sql="select *from Gym where (GymID like'%$key%' or GymName like'%$key%' )";
		$result=$conn->query($sql);
		while($my_row=$result->fetch_assoc())
		{
			$GymID=$my_row['GymID'];
			$GymName=$my_row['GymName'];
			
			$GymList[]=new Gym($GymID,$GymName);	
		}
		require("connection_close.php");
		return $GymList;
	}
	public static function update($GymID,$GymName)
	{
	
		require("connection_connect.php");
		$sql="UPDATE Gym SET GymName = '$GymName' WHERE GymID = '$GymID'";
		$result=$conn->query($sql);
		require("connection_close.php");
		return "update success $result row";
	}

	public static function get($id)
	{
		require("connection_connect.php");
		$sql="select *from Gym where GymID='$id'";;
		$result=$conn->query($sql);
		$my_row=$result->fetch_assoc();
		$id=$my_row['GymID'];
		$GymName=$my_row['GymName'];
	
		require("connection_close.php");

		return new Gym($id,$GymName);
	}
	public static function delete($id)
	{
		require("connection_connect.php");
		$sql="Delete from Gym	 where GymID='$id'";
		$result=$conn->query($sql);
		require("connection_close.php");
		return "delete success $result row";
	}

}?>