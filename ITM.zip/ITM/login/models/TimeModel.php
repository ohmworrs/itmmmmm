<?php
Class Time{
Public $TimeID;
Public $TimeStart;
Public $TimeFinish;


Public function Time($TimeID,$TimeStart,$TimeFinish)
{            
           $this->TimeID = $TimeID;
           $this->TimeStart = $TimeStart;
           $this->TimeFinish = $TimeFinish;
           ;
}
public static function getAll()
{
	$TimeList=[];
	require_once("../connection_connect.php");
	$sql = "select * from Time";
	$result=$conn->query($sql);
	
	while ($my_row=$result->fetch_assoc())
		{

			$TimeID=$my_row['TimeID'];
			$TimeStart=$my_row['TimeStart'];
			$TimeFinish=$my_row['TimeFinish'];
			
			$TimeList[]=new Time($TimeID,$TimeStart,$TimeFinish);
		}
		require("connection_close.php");
		return $TimeList;
}

public static function add($TimeID,$TimeStart,$TimeFinish)
{
	require("connection_connect.php");
	$sql="insert into Time(TimeID,TimeStart, TimeFinish)
	values('$TimeID','$TimeStart','$TimeFinish')";
	$result=$conn->query($sql);
	require("connection_close.php");
	return "add success $result rows";
}

public static function search($key)
{
	$TimeList=[];
	require("connection_connect.php");
	$sql="select *from Time where (TimeID like'%$key%' or TimeStart like'%$key%' or TimeFinish like'%$key%')";
	$result=$conn->query($sql);
	while($my_row=$result->fetch_assoc())
	{
		$TimeID=$my_row['TimeID'];
		$TimeStart=$my_row['TimeStart'];
		$TimeFinish=$my_row['TimeFinish'];
		$TimeList[]=new Time($TimeID,$TimeStart,$TimeFinish);	
	}
	require("connection_close.php");
	return $TimeList;
}

public static function get($id)
{
	require("connection_connect.php");
	$sql="select *from time where TimeID='$id'";;
	$result=$conn->query($sql);
	$my_row=$result->fetch_assoc();
	$id=$my_row['TimeID'];
	$TimeStart=$my_row['TimeStart'];
	$TimeFinish=$my_row['TimeFinish'];
	require("connection_close.php");

	return new Time($id,$TimeStart,$TimeFinish);
}

public static function update($TimeID,$TimeStart,$TimeFinish)
{
	
	require("connection_connect.php");
	$sql="UPDATE Time SET TimeStart = '$TimeStart', TimeFinish = '$TimeFinish' WHERE TimeID = '$TimeID'";
	$result=$conn->query($sql);
	require("connection_close.php");
	return "update success $result row";
}

public static function delete($id)
{
	require("connection_connect.php");
	$sql="Delete from Time	 where TimeID='$id'";
	$result=$conn->query($sql);
	require("connection_close.php");
	return "delete success $result row";
}
}?>