<?php
Class RateBadminton{
Public $RateBadmintonID;
Public $TypeRatePerson;
Public $TerminalGym;
Public $PriceMemberPerYear;
Public $PriceMember;
Public $PriceNotMember;

Public function RateBadminton($RateBadmintonID,$TypeRatePerson, $TerminalGym, $PriceMemberPerYear, $PriceMember ,$PriceNotMember)
{            
           $this->RateBadmintonID = $RateBadmintonID;
           $this->TypeRatePerson = $TypeRatePerson;
           $this->TerminalGym = $TerminalGym;
           $this->PriceMemberPerYear= $PriceMemberPerYear;
           $this->PriceMember = $PriceMember;
           $this->PriceNotMember = $PriceNotMember;
}
public static function getAll()
{
	$RateBadmintonList=[];
	require("connection_connect.php");
	$sql = "select * from RateBadminton";
	$result = $conn->query($sql);
	
	while ($my_row=$result->fetch_assoc())
		{

			$RateBadmintonID=$my_row['RateBadmintonID'];
			$TypeRatePerson=$my_row['TypeRatePerson'];
			$TerminalGym=$my_row['TerminalGym'];
			$PriceMemberPerYear=$my_row['PriceMemberPerYear'];
			$PriceMember=$my_row['PriceMember'];
			$PriceNotMember=$my_row['PriceNotMember'];
			$RateBadmintonList[]=new RateBadminton($RateBadmintonID,$TypeRatePerson, $TerminalGym, $PriceMemberPerYear, $PriceMember ,$PriceNotMember);
		}
		require("connection_close.php");
		return $RateBadmintonList;
}

public static function add($RateBadmintonID,$TypeRatePerson, $TerminalGym, $PriceMemberPerYear, $PriceMember ,$PriceNotMember)
{
	require("connection_connect.php");
	$sql="insert into RateBadminton(RateBadmintonID,TypeRatePerson, TerminalGym, PriceMemberPerYear, PriceMember ,PriceNotMember)
	values('$RateBadmintonID','$TypeRatePerson', '$TerminalGym', '$PriceMemberPerYear', '$PriceMember' ,'$PriceNotMember')";
	$result=$conn->query($sql);
	require("connection_close.php");
	return "add success $result rows";
}

public static function search($key)
{
	$RateBadmintonList=[];
	require("connection_connect.php");
	$sql="select *from RateBadminton where(RateBadmintonID like'%$key%' or TypeRatePerson like'%$key%' or
	TerminalGym like'%$key%' or PriceMemberPerYear like'%$key%' or PriceMember like'%$key%' or PriceNotMember like'%$key%')";
	$result=$conn->query($sql);
	while($my_row=$result->fetch_assoc())
	{
		$RateBadmintonID=$my_row['RateBadmintonID'];
		$TypeRatePerson=$my_row['TypeRatePerson'];
		$TerminalGym=$my_row['TerminalGym'];
		$PriceMemberPerYear=$my_row['PriceMemberPerYear'];
		$PriceMember=$my_row['PriceMember'];
		$PriceNotMember=$my_row['PriceNotMember'];
		$RateBadmintonList[]=new RateBadminton($RateBadmintonID,$TypeRatePerson, $TerminalGym, $PriceMemberPerYear, $PriceMember ,$PriceNotMember);
	}
	require("connection_close.php");
	return $RateBadmintonList;
}

public static function update($RateBadmintonID,$TypeRatePerson, $TerminalGym, $PriceMemberPerYear, $PriceMember ,$PriceNotMember)
{
	require("connection_connect.php");
	$sql="UPDATE RateBadminton SET TypeRatePerson = '$TypeRatePerson', TerminalGym = '$TerminalGym', PriceMemberPerYear = '$PriceMemberPerYear',PriceMember = '$PriceMember', PriceNotMember = '$PriceMember', PriceNotMember = '$PriceNotMember' WHERE RateBadmintonID = '$RateBadmintonID'";
	$result=$conn->query($sql);
	require("connection_close.php");
	return "update success $result row";
}

public static function get($id)
{
	require("connection_connect.php");
	$sql="select *from RateBadminton where RateBadmintonID='$id'";;
	$result=$conn->query($sql);
	$my_row=$result->fetch_assoc();
	$id=$my_row['RateBadmintonID'];
	$TypeRatePerson=$my_row['TypeRatePerson'];
	$TerminalGym=$my_row['TerminalGym'];
	$PriceMemberPerYear=$my_row['PriceMemberPerYear'];
	$PriceMember=$my_row['PriceMember'];
	$PriceNotMember=$my_row['PriceNotMember'];
	require("connection_close.php");

	return new RateBadminton($id, $TypeRatePerson, $TerminalGym, $PriceMemberPerYear, $PriceMember ,$PriceNotMember);
}

public static function delete($id)
{
	require("connection_connect.php");
	$sql="Delete from RateBadminton where RateBadmintonID='$id'";
	$result=$conn->query($sql);
	require("connection_close.php");
	return "delete success $result row";
}
}?>