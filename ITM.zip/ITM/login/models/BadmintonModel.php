<?php class Badminton{
	public $BadmintonID,$BadmintonCourt,$StatusCourt,$GymID,$TimeID;
	public function Badminton($BadmintonID,$BadmintonCourt,$StatusCourt,$GymID,$TimeID)
	{
		$this->BadmintonID = $BadmintonID;
		$this->BadmintonCourt = $BadmintonCourt;
        $this->StatusCourt = $StatusCourt;
        $this->GymID=$GymID;
        $this->TimeID=$TimeID;
	}
	public static function getAll()
	{
		$BadmintonList=[];
		require("connection_connect.php");
		$sql="select * from Badminton";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
			$BadmintonID=$my_row['BadmintonID'];
			$BadmintonCourt=$my_row['BadmintonCourt'];
            $StatusCourt=$my_row['StatusCourt'];
            $GymID=$my_row['GymID'];
            $TimeID=$my_row['TimeID'];
			$BadmintonList[]=new Badminton($BadmintonID,$BadmintonCourt,$StatusCourt,$GymID,$TimeID);
		}
		require("connection_close.php");
		return $BadmintonList;
		
		
	}
	public static function add($BadmintonID,$BadmintonCourt,$StatusCourt,$GymID,$TimeID)
	{	
		require("connection_connect.php");
		$sql="insert into Badminton(BadmintonID,BadmintonCourt, StatusCourt, GymID, TimeID)
		values('$BadmintonID','$BadmintonCourt','$StatusCourt','$GymID','$TimeID')";
		$result=$conn->query($sql);
		require("connection_close.php");
		return "add success $result rows";
	}

	public static function search($key)
	{
		$BadmintonList=[];
		require("connection_connect.php");
		$sql="select *from Badminton where (BadmintonID like'%$key%' or BadmintonCourt like'%$key%' or StatusCourt like'%$key%' or GymID like'%$key%' or TimeID like'%$key%' )";
		$result=$conn->query($sql);
		while($my_row=$result->fetch_assoc())
		{
			$BadmintonID=$my_row['BadmintonID'];
			$BadmintonCourt=$my_row['BadmintonCourt'];
            $StatusCourt=$my_row['StatusCourt'];
            $GymID=$my_row['GymID'];
            $TimeID=$my_row['TimeID'];
			$BadmintonList[]=new Badminton($BadmintonID,$BadmintonCourt,$StatusCourt,$GymID,$TimeID);	
		}
		require("connection_close.php");
		return $BadmintonList;
	}

	public static function update($BadmintonID,$BadmintonCourt,$StatusCourt,$GymID,$TimeID)
{
	
	require("connection_connect.php");
	$sql="UPDATE Badminton SET BadmintonCourt = '$BadmintonCourt', StatusCourt = '$StatusCourt', GymID = '$GymID',TimeiD = '$TimeID' WHERE BadmintonID = '$BadmintonID'";
	$result=$conn->query($sql);
	require("connection_close.php");
	return "update success $result row";
}

public static function get($id)
{
	require("connection_connect.php");
	$sql="select *from Badminton where BadmintonID='$id'";;
	$result=$conn->query($sql);
	$my_row=$result->fetch_assoc();
	$id=$my_row['BadmintonID'];
	$BadmintonCourt=$my_row['BadmintonCourt'];
	$StatusCourt=$my_row['StatusCourt'];
	$GymID=$my_row['GymID'];
    $TimeID=$my_row['TimeID'];
	require("connection_close.php");

	return new Badminton($id,$BadmintonCourt,$StatusCourt,$GymID,$TimeID);
}

public static function delete($id)
	{
		require("connection_connect.php");
		$sql="Delete from Badminton	 where BadmintonID='$id'";
		$result=$conn->query($sql);
		require("connection_close.php");
		return "delete success $result row";
	}



}?>