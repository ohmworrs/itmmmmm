<table border = 1>
<tr> <td>RateBadmintonID</td><td>TypeRatePerson</td><td>TerminalGym</td><td>PriceMemberPerYear</td><td>PriceMember</td><td>PriceNotMember</td><td>อัพเดท</td><td>ลบ</td></tr>

<form method="get" action="">
	<input type="text" name="key">
	<input type="hidden" name="controller" value="RateBadminton"/>
	<button type="submit" name="action" value="search">
Search</button>
</form>
<?php foreach($RateBadmintonList as $RateBadminton)
{
	echo"<tr> <td>$RateBadminton->RateBadmintonID</td>
	<td>$RateBadminton->TypeRatePerson</td> 
	<td>$RateBadminton->TerminalGym</td>
	<td>$RateBadminton->PriceMemberPerYear</td> 
	<td>$RateBadminton->PriceMember</td>
	<td>$RateBadminton->PriceNotMember</td>
	<td><a href=?controller=RateBadminton&action=updateForm&RateBadmintonID=$RateBadminton->RateBadmintonID>updete</a></td>
	<td><a href=?controller=RateBadminton&action=deleteConfirm&RateBadmintonID=$RateBadminton->RateBadmintonID>delete</a></td>"; 

}

echo "</table>";
?>
<html>
<head></head>
<body>
    เพิ่มอัตราการบริการ[<a href=?controller=RateBadminton&action=newRateBadminton>Click</a>]
</body>
</html>	
