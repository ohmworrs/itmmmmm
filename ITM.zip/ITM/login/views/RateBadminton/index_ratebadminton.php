<table border = 1>
<tr> <td>RateBadmintonID</td><td>TypeRatePerson</td><td>TerminalGym</td><td>PriceMemberPerYear</td><td>PriceMember</td><td>PriceNotMember</td></tr>
<?php foreach($RateBadmintonList as $RateBadminton)
{
	echo"<tr> <td>$RateBadminton->RateBadmintonID</td>
	<td>$RateBadminton->TypeRatePerson</td> <td>$RateBadminton->TerminalGym</td>
	<td>$RateBadminton->PriceMember</td> <td>$RateBadminton->PriceMember</td>
	<td>$RateBadminton->PriceNotMember</td>"; 
}

echo "</table>";
?>
<html>
<head></head>
<body>
    เพิ่มอัตราการบริการ[<a href=?controller=RateBadminton&action=newRateBadminton>Click</a>]
</body>
</html>	
