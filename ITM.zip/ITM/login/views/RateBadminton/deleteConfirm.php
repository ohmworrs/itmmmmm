<?php echo "<br>Are you sure to delete this RateBadminton <br>
            <br>$RateBadminton->RateBadmintonID $RateBadminton->TypeRatePerson $RateBadminton->TerminalGym $RateBadminton->PriceMemberPerYear $RateBadminton->PriceMember $RateBadminton->PriceNotMember <br>";?>
<form method="get" action="">"
    <input type="hidden" name="controller" value="RateBadminton"/>
    <input type="hidden" name="RateBadmintonID" value="<?php echo $RateBadminton->RateBadmintonID; ?>" />
    <button type="submit" name="action" value="index">Back</button>
    <button type="submit" name="action" value="delete">Delete</button>
</form>