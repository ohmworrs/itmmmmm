<html>
<head></head>
<body>
<form method="get" action="">
<label> RateBadmintonID<input type="int" name="RateBadmintonID" /> </label><br>
<label>ประเภทบุคคล <input type="text" name="TypeRatePerson" /> </label><br>
<label>อาคาร<input type="text" name="TerminalGym" /> </label><br>
<label>ค่าสมาชิกต่อปี<input type="int" name="PriceMemberPerYear" /> </label><br>
<label>ค่าบริการ(เป็นสามชิก)<input type="int" name="PriceMember" /> </label><br>
<label>ค่าบริการ(ไม่เป็นสามาชิก)<input type="int" name="PriceNotMember" /> </label><br>



<input type="hidden" name="controller" value="RateBadminton"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addRateBadminton"> Save</button>

</form>



</body>
</html>




