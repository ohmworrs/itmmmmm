<form method = "get" action="">
    <label>RateBadmintonID<input type="int" name="RateBadmintonID"
        value="<?php echo $RateBadminton->RateBadmintonID; ?>" /> </label><br>
     <label>TypeRatePerson<input type="text" name="TypeRatePerson"
        value="<?php echo $RateBadminton->TypeRatePerson; ?>" /> </label><br>
    <label>TerminalGym<input type="text" name="TerminalGym"
        value="<?php echo $RateBadminton->TerminalGym; ?>" /> </label><br>
    <label>PriceMemberPerYear<input type="int" name="PriceMemberPerYear"
        value="<?php echo $RateBadminton->PriceMemberPerYear; ?>" /> </label><br>
    <label>PriceMember<input type="int" name="PriceMember"
        value="<?php echo $RateBadminton->PriceMember; ?>" /> </label><br>
     <label>PriceNotMember<input type="int" name="PriceNotMember"
        value="<?php echo $RateBadminton->PriceNotMember; ?>" /> </label><br>
    </label>

<input type="hidden" name="controller" value="RateBadminton"/>
<button type="submit" name="action" value="index">Back</button>
<button type="submit" name="action" value="update">update</button>
</form>