<html>
<head></head>
<body>
<form method="get" action="">
<label>ชื่อผู้จอง <input type="text" name="ReserveName" /> </label><br>
<label>เบอร์โทร <input type="text" name="ReserveTel" /> </label><br>
<label>อีเมลล์<input type="text" name="ReserveEmail" /> </label><br>
<label>ประเภทบุคคล <select name="TypePerson">
    <?php echo "<option value=''></option>";
          echo "<option value='เด็กอายุต่ำกว่า13'>เด็กอายุต่ำกว่า13</option>";
          echo "<option value='นักเรียนและนิสิต'>นักเรียนและนิสิต</option>";
          echo "<option value='บุคลากร'>บุคลากร</option>";
          echo "<option value='บุคคลทั่วไป'>บุคคลทั่วไป</option>";
    ?>
</select></label><br>

<label>คอร์ดแบต<input type="text" name="BadmintonCourt" /> </label><br>
<label>อาคาร<input type="text" name="TerminalGym" /> </label><br>
<label>เวลาเริ่ม<input type="time" name="TimeStart" step=2 /> </label><br>
<label>เวลาสิ้นสุด<input type="time" name="TimeFinish" step=2 /> </label><br>
<label>ไอดีของสนาม<input type="int" name="BadmintonID" /> </label><br>

<input type="hidden" name="controller" value="Reserve"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addReserve"> Save</button>





</body>
</html>




