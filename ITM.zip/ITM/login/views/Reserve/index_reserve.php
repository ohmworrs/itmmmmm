<table border = 6>
<tr> <td>ReserveID</td><td>ReserveName</td><td>ReserveTel</td><td>ReserveEmail</td><td>TimeID</td><td>BadmintonID</td><td>deleteReserve</td></tr>

<form method="get" action="">
	<input type="text" name="key">
	<input type="hidden" name="controller" value="Reserve"/>
	<button type="submit" name="action" value="search">
Search</button>
<?php 
foreach($ReserveList as $Reserve)
{
	echo"<tr><td>$Reserve->ReserveID</td>
    <td>$Reserve->ReserveName</td> 
    <td>$Reserve->ReserveTel</td>
    <td>$Reserve->ReserveEmail</td> 
    <td>$Reserve->TimeID</td>
    <td>$Reserve->BadmintonID</td>
    <td><a href=?controller=Reserve&action=deleteConfirm&ReserveID=$Reserve->ReserveID>delete</a> </tr>"; 
    
}
echo "</table>";
?>
<html>
<head></head>
<body>
    เพิ่มการจอง [<a href=?controller=Reserve&action=newReserve>Click</a>]
</body>
</html>	


