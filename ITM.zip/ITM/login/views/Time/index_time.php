<table border = 1>
<tr> <td>TimeID</td><td>TimeStart</td><td>TimeFinish</td><td>update</td><td>delete</td></tr>

<form method="get" action="">
	<input type="text" name="key">
	<input type="hidden" name="controller" value="Time"/>
	<button type="submit" name="action" value="search">
Search</button>
</form>
<?php foreach($TimeList as $Time)
{
	echo"<tr> <td>$Time->TimeID</td>
    <td>$Time->TimeStart</td>
     <td>$Time->TimeFinish</td>
     <td><a href=?controller=Time&action=updateForm&TimeID=$Time->TimeID>updete</a></td>
     <td><a href=?controller=Time&action=deleteConfirm&TimeID=$Time->TimeID>delete</a></td>"; 
    }
echo "</table>";
?>
<html>
<head></head>
<body>
    เพิ่มเวลา[<a href=?controller=Time&action=newTime>Click</a>]
</body>
</html>	
