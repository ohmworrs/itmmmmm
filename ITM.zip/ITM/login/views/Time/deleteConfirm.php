<?php echo "<br>Are you sure to delete this RateBadminton <br>
            <br>$Time->TimeID $Time->TimeStart $Time->TimeFinish  <br>";?>
<form method="get" action="">
    <input type="hidden" name="controller" value="Time"/>
    <input type="hidden" name="TimeID" value="<?php echo $Time->TimeID; ?>" />
    <button type="submit" name="action" value="index">Back</button>
    <button type="submit" name="action" value="delete">Delete</button>
</form>