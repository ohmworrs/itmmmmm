<html>
<head></head>
<body>
<form method="get" action="">
<label>TimeID<input type="int" name="TimeID" /> </label><br>
<label>TimeStart <input type="time" step ="2" name="TimeStart" /> </label><br>
<label>TimeFinish <input type="time" step ="2" name="TimeFinish" /> </label><br>


<input type="hidden" name="controller" value="Time"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addTime"> Save</button>





</body>
</html>




