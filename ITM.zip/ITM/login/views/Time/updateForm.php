<form method = "get" action="">
    <label>TimeID<input type="int" name="TimeID"
        value="<?php echo $Time->TimeID; ?>" /> </label><br>
     <label>TimeStart<input type="time" step="2" name="TimeStart"
        value="<?php echo $Time->TimeStart; ?>" /> </label><br>
    <label>TimeFinish<input type="time" step="2" name="TimeFinish"
        value="<?php echo $Time->TimeFinish; ?>" /> </label><br>
    

<input type="hidden" name="controller" value="Time"/>
<button type="submit" name="action" value="index">Back</button>
<button type="submit" name="action" value="update">Update</button>
</form>