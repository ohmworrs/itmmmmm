<html>
<head></head>
<body>
<form method="get" action="">
<label>BadmintonID<input type="int" name="BadmintonID" /> </label><br>
<label>BadmintonCourt <input type="text" name="BadmintonCourt" /> </label><br>
<label>StatusCourt <input type="text" name="StatusCourt" /> </label><br>
<label>GymID <select name="GymID" > 
    <?php foreach($GymList as $Gym)
    {
        echo "<option valueTime = $Gym->GymID>$Gym->GymID</option>";
    }
    ?> 
</select></label><br>
<label>TimeID <select name="TimeID" > 
    <?php foreach($TimeList as $Time)
    {
        echo "<option valueTime = $Time->TimeID>$Time->TimeID</option>";
    }
    ?> 
</select></label><br>

<input type="hidden" name="controller" value="Badminton"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addBadminton"> Save</button>





</body>
</html>