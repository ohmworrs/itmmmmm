<form method = "get" action="">
    <label>BadmintonID<input type="int" name="BadmintonID"
        value="<?php echo $Badminton->BadmintonID; ?>" /> </label><br>
     <label>BadmintonCourt<input type="text" name="BadmintonCourt"
        value="<?php echo $Badminton->BadmintonCourt; ?>" /> </label><br>
    <label>StatusCourt<input type="text" name="StatusCourt"
        value="<?php echo $Badminton->StatusCourt; ?>" /> </label><br>

    <label>GymID <select name="GymID">
            <?php foreach($GymList as $Gym){
                echo "<option value=$Gym->GymID";
                if($Gym->GymID==$Badminton->GymID){
                    echo "selected='selected'";
                }
                echo ">$Gym->GymName</option>";
            } ?>
    </select></label><br>

    <label>TimeID <select name="TimeID">
            <?php foreach($TimeList as $Time){
                echo "<option value=$Time->TimeID";
                if($Time->TimeID==$Badminton->TimeID){
                    echo "$Time->TimeID";
                }
                echo ">$Time->TimeStart-$Time->TimeFinish</option>";
            } ?>
    </select></label><br>
       
    

<input type="hidden" name="controller" value="Badminton"/>
<button type="submit" name="action" value="index">Back</button>
<button type="submit" name="action" value="update">update</button>
</form>