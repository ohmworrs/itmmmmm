<table border = 1>
<tr> <td>BadmintonID</td><td>BadmintonCourt</td><td>StatusCourt</td><td>GymID</td><td>TimeID</td><td>Update</td><td>Delete</td></tr>

<form method="get" action="">
	<input type="text" name="key">
	<input type="hidden" name="controller" value="Badminton"/>
	<button type="submit" name="action" value="search">
Search</button>

<?php foreach($BadmintonList as $Badminton)
{
	echo"<tr> <td>$Badminton->BadmintonID</td>
    <td>$Badminton->BadmintonCourt</td>
    <td>$Badminton->StatusCourt</td>
    <td>$Badminton->GymID</td>
    <td>$Badminton->TimeID</td>
    <td><a href=?controller=Badminton&action=updateForm&BadmintonID=$Badminton->BadmintonID>update</td>
    <td><a href=?controller=Badminton&action=deleteConfirm&BadmintonID=$Badminton->BadmintonID>delete</td></tr>"; 
}
echo "</table>";
?>
<html>
<head></head>
<body>
        เพิ่มคอร์ด[<a href=?controller=Badminton&action=newBadminton> click </a>]
</body>
</html>