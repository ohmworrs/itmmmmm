<form method = "get" action="">
    <label>MemberBadmintonID<input type="int" name="MemberBadmintonID"
        value="<?php echo $MemberBadminton->MemberBadmintonID; ?>" /> </label><br>
     <label>MemberName<input type="text" name="MemberName"
        value="<?php echo $MemberBadminton->MemberName; ?>" /> </label><br>
    <label>MemberAddress<input type="text" name="MemberAddress"
        value="<?php echo $MemberBadminton->MemberAddress; ?>" /> </label><br>
    <label>MemberTel<input type="int" name="MemberTel"
        value="<?php echo $MemberBadminton->MemberTel; ?>" /> </label><br>
    <label>MemberEmail<input type="int" name="MemberEmail"
        value="<?php echo $MemberBadminton->MemberEmail; ?>" /> </label><br>
     <label>TypeMember<input type="int" name="TypeMember"
        value="<?php echo $MemberBadminton->TypeMember; ?>" /> </label><br>
    </label>

<input type="hidden" name="controller" value="MemberBadminton"/>
<button type="submit" name="action" value="index">Back</button>
<button type="submit" name="action" value="update">update</button>
</form>