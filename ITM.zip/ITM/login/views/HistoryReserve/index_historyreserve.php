<table border = 1>
<tr> <td>HistoryReserveID</td><td>ReserveName</td><td>ReserveTel</td><td>ReserveEmail</td><td>TypePerson</td><td>NotOrMember</td><td>Price</td><td>BadmintonID</td><td>Date</td></tr>

<form method="get" action="">
	<input type="text" name="key">
	<input type="hidden" name="controller" value="HistoryReserve"/>
	<button type="submit" name="action" value="search">
Search</button>
<?php 
foreach($HistoryReserveList as $HistoryReserve)
{
    echo"<tr><td>$HistoryReserve->HistoryReserveID</td>
    <td>$HistoryReserve->ReserveName</td> 
    <td>$HistoryReserve->ReserveTel</td>
    <td>$HistoryReserve->ReserveEmail</td> 
    <td>$HistoryReserve->TypePerson</td> 
    <td>$HistoryReserve->NotOrMember</td> 
    <td>$HistoryReserve->Price</td> 
    <td>$HistoryReserve->BadmintonID</td>
	<td>$HistoryReserve->ReserveDate</td></tr>"; 
    
}
echo "</table>";
?>
