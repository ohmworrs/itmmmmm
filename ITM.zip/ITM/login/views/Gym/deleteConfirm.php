<?php echo "<br>Are you sure to delete this Gym <br>
            <br>$Gym->GymID $Gym->GymName <br>";?>
<form method="get" action="">"
    <input type="hidden" name="controller" value="Gym"/>
    <input type="hidden" name="GymID" value="<?php echo $Gym->GymID; ?>" />
    <button type="submit" name="action" value="index">Back</button>
    <button type="submit" name="action" value="delete">Delete</button>
</form>