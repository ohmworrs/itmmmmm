<table border = 1>
<tr> <td>GymID</td><td>GymName</td><td>update</td><td>delete</td></tr>

<form method="get" action="">
	<input type="text" name="key">
	<input type="hidden" name="controller" value="Gym"/>
	<button type="submit" name="action" value="search">
Search</button>
</form>

<?php foreach($GymList as $Gym)
{
	echo"<tr> <td>$Gym->GymID</td>
    <td>$Gym->GymName</td>
    <td><a href=?controller=Gym&action=updateForm&GymID=$Gym->GymID>updete</a></td>
    <td><a href=?controller=Gym&action=deleteConfirm&GymID=$Gym->GymID>delete</a></td></tr>"; 
}
echo "</table>";
?>
<html>
<head></head>
<body>
        เพิ่มอาคาร[<a href=?controller=Gym&action=newGym> click </a>]
</body>
</html>
