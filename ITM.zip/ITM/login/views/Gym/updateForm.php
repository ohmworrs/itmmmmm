<form method="get" action="">
<label> GymID<input type="int" name="GymID"
value="<?php echo $Gym->GymID; ?>" /> </label><br>
<label>GymName <input type="text" name="GymName" 
value="<?php echo $Gym->GymName; ?>"/> </label><br>

<input type="hidden" name="controller" value="Gym"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="update"> Save</button>

</form>