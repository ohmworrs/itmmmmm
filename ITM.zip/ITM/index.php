<?php

//error_reporting (E_ALL ^ E_NOTICE);	

if (isset($_GET['controller'])&&isset($_GET['action']))
{
	$controller = $_GET['controller'];
	$action = $_GET['action'];
}
else 
{
	$controller = 'pages';
	$action = 'home';
}?>
<html>
<head></head>
<body>
		
<?php echo "controller=".$controller.",action=".$action;?>
	<br>

	
	<center>
	[<a href="./?controller=index.php">Home</a>]
	[<a href="./?controller=BadmintonTable&action=index">ตารางแบดมินตัน</a>]
	[<a href="./?controller=RateBadminton&action=index">อัตราการใช้บริการ</a>]
	[<a href="./?controller=Reserve&action=index">จอง</a>]<br>
	
  [<a href="./login/loginform.php">Admin</a>]<br>
  

		<br>
</body>	
	 <?php require_once("routes.php");?> 
	

</html>	
	
