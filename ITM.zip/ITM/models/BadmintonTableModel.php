<?php class BadmintonTable{
	public $BadmintonID,$BadmintonCourt,$TerminalGym,$TimeStart,$TimeFinish,$StatusCourt;
	public function BadmintonTable($BadmintonID,$BadmintonCourt,$TerminalGym,$TimeStart,$TimeFinish,$StatusCourt)
	{
		$this->BadmintonID = $BadmintonID;
		$this->BadmintonCourt = $BadmintonCourt;
		$this->TerminalGym = $TerminalGym;
		$this->TimeStart = $TimeStart;
		$this->TimeFinish = $TimeFinish;
		$this->StatusCourt = $StatusCourt;
	}

	public static function get($id)
{
  require("connection_connect.php");
  $sql = "select *from badmintonshoww where BadmintonID='$id'";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $BadmintonID=$my_row['BadmintonID'];
  $BadmintonCourt=$my_row['BadmintonCourt'];
  $TerminalGym=$my_row['TerminalGym'];
  $TimeStart=$my_row['TimeStart'];
  $TimeFinish=$my_row['TimeFinish'];
  $StatusCourt=$my_row['StatusCourt'];
  require("connection_close.php");

  return new BadmintonTable($BadmintonID,$BadmintonCourt,$TerminalGym,$TimeStart,$TimeFinish,$StatusCourt);
}
	public static function getAll()
	{
		$BadmintonTableList=[];
		require("connection_connect.php");
		$sql="select * from badmintonshoww";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
			$BadmintonID=$my_row['BadmintonID'];
			$BadmintonCourt=$my_row['BadmintonCourt'];
			$TerminalGym=$my_row['TerminalGym'];
			$TimeStart=$my_row['TimeStart'];
			$TimeFinish=$my_row['TimeFinish'];
			$StatusCourt=$my_row['StatusCourt'];
			$BadmintonTableList[]=new BadmintonTable($BadmintonID,$BadmintonCourt,$TerminalGym,$TimeStart,$TimeFinish,$StatusCourt);
		}
		require("connection_close.php");
		return $BadmintonTableList;
		
		
	}
	public static function search($key)
	{
		$BadmintonTableList=[];
		require_once("connection_connect.php");
		$sql="select *from badmintonshoww
		where (BadmintonID like'%$key%' or BadmintonCourt like'%$key%' or TerminalGym like'%$key%' or TimeStart like'%$key%' or TimeFinish like'%$key%' or StatusCourt like'%$key%')";
		$result=$conn->query($sql);
		while ($my_row=$result->fetch_assoc())	
		{
			$BadmintonID=$my_row['BadmintonID'];
			$BadmintonCourt=$my_row['BadmintonCourt'];
			$TerminalGym=$my_row['TerminalGym'];
			$TimeStart=$my_row['TimeStart'];
			$TimeFinish=$my_row['TimeFinish'];
			$StatusCourt=$my_row['StatusCourt'];
			$BadmintonTableList[]=new BadmintonTable($BadmintonID,$BadmintonCourt,$TerminalGym,$TimeStart,$TimeFinish,$StatusCourt);
		}
		require("connection_close.php");
		return $BadmintonTableList;

	}
}?>