<?php class Badminton{
	public $BadmintonID,$BadmintonCourt,$StatusCourt,$GymID,$TimeID;
	public function Badminton($BadmintonID,$BadmintonCourt,$StatusCourt,$GymID,$TimeID)
	{
		$this->BadmintonID = $BadmintonID;
		$this->BadmintonCourt = $BadmintonCourt;
        $this->StatusCourt = $StatusCourt;
        $this->GymID=$GymID;
        $this->TimeID=$TimeID;
	}
	public static function getAll()
	{
		$BadmintonList=[];
		require("connection_connect.php");
		$sql="select * from Badminton";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
			$BadmintonID=$my_row['BadmintonID'];
			$BadmintonCourt=$my_row['BadmintonCourt'];
            $StatusCourt=$my_row['StatusCourt'];
            $GymID=$my_row['GymID'];
            $TimeID=$my_row['TimeID'];
			$BadmintonList[]=new Badminton($BadmintonID,$BadmintonCourt,$StatusCourt,$GymID,$TimeID);
		}
		require("connection_close.php");
		return $BadmintonList;
		
		
	}
}?>