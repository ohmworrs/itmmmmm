<?php class RateBadmintonController
{
	public function index()
	{
		$RateBadmintonList=RateBadminton::getAll();
		require_once('views/RateBadminton/index_ratebadminton.php');
	}
}?>