<?php class BadmintonTableController
{
	public function index(){
		$BadmintonTableList = BadmintonTable::getAll();
		require_once('views/BadmintonTable/index_badmintontable.php');
	}

	public function search()
	{
		$key=$_GET['key'];
		$BadmintonTableList=BadmintonTable::search($key);
		require_once('views/BadmintonTable/index_badmintontable.php');

	}
}?>