<?php 
class ReserveController
{	
	public function index()
	{	$ReserveList= Reserve::getAll();
		require_once('views/Reserve/index_reserve.php');
	}

	public function newReserve()
	{
		$TimeList=Time::getAll();
		$BadmintonList=Badminton::getAll();
		require_once("views/Reserve/newReserve.php");
		
	}
	public function addReserve()
	{
		$ReserveID=$_GET['ReserveID'];
		$ReserveName=$_GET['ReserveName'];
		$ReserveTel=$_GET['ReserveTel'];
		$ReserveEmail=$_GET['ReserveEmail'];
		$TimeID=$_GET['TimeID'];
		$BadmintonID=$_GET['BadmintonID'];
		Reserve::Add($ReserveID,$ReserveName,$ReserveTel,$ReserveEmail,$TimeID,$BadmintonID);
		ReserveController::index();
	}
}?>