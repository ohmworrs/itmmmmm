<?php class BadmintonController
{
	public function index(){
		$BadmintonList = Badminton::getAll();
		require_once('views/Badminton/index_badminton.php');
	}
}?>