<html>
<head></head>
<body>
<form method="get" action="">
<label>ชื่อผู้จอง <input type="text" name="ReserveName" /> </label><br>
<label>เบอร์โทร <input type="text" name="ReserveTel" /> </label><br>
<label>อีเมลล์<input type="text" name="ReserveEmail" /> </label><br>
<label>ประเภทบุคคล <select name="TypePerson">
    <?php echo "<option value=''></option>";
          echo "<option value='เด็กอายุต่ำกว่า13'>เด็กอายุต่ำกว่า13</option>";
          echo "<option value='นักเรียนและนิสิต'>นักเรียนและนิสิต</option>";
          echo "<option value='บุคลากร'>บุคลากร</option>";
          echo "<option value='บุคคลทั่วไป'>บุคคลทั่วไป</option>";
    ?>
</select></label><br>

<label>คอร์ดแบต<input type="text" name="BadmintonCourt" readonly="true" 
    value="<?php echo $BadmintonTable->BadmintonCourt;?>"/> </label><br>
<label>อาคาร<input type="text" name="TerminalGym" readonly="true" 
    value="<?php echo $BadmintonTable->TerminalGym;?>"/> </label><br>
<label>เวลาเริ่ม<input type="text" name="TimeStart" readonly="true"
    value="<?php echo $BadmintonTable->TimeStart;?>"/> </label><br>
<label>เวลาสิ้นสุด<input type="text" name="TimeFinish" readonly="true"
    value="<?php echo $BadmintonTable->TimeFinish;?>"/> </label><br>
<label>ไอดีของสนาม<input type="int" name="BadmintonID" readonly="true"
    value="<?php echo $BadmintonTable->BadmintonID;?>"/> </label><br>

<input type="hidden" name="controller" value="Reserve"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addReserve" onclick="alert('ยืนยันการจองของคุณหรือไม่?')"> Save</button>





</body>
</html>




