<html>
<head></head>
<body>
<form method="get" action="">
<label>ไอดีการจอง <input type="int" name="ReserveID" /> </label><br>
<label>ชื่อผู้จอง <input type="text" name="ReserveName" /> </label><br>
<label>เบอร์โทร <input type="text" name="ReserveTel" /> </label><br>
<label>อีเมลล์<input type="text" name="ReserveEmail" /> </label><br>
<label>ช่วงเวลาเริ่ม <select name="TimeID" > 
    <?php foreach($TimeList as $Time)
    {
        echo "<option valueTime = $Time->TimeID>$Time->TimeID</option>";
    }
    ?> 
     </select></label><br>
<label>BadmintonID <select name="BadmintonID"> 
   / <?php foreach($BadmintonList as $Badminton)
    {
        echo "<option valueBad = $Badminton->BadmintonID>$Badminton->BadmintonID</option>";
    }?>
     </select></label><br>
<input type="hidden" name="controller" value="Reserve"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addReserve"> Save</button>





</body>
</html>




