<table border = 1>
<tr> <td>ReserveName</td><td>ReserveTel</td><td>ReserveEmail</td><td>TypePerson</td><td>BadmintonCourt</td><td>TerminalGym</td><td>TimeStart</td><td>Timefinish</td><td>BadmintonID</td></tr>
<?php 

foreach($ReserveList as $Reserve)
{
	echo"<tr>
    <td>$Reserve->ReserveName</td> 
    <td>$Reserve->ReserveTel</td>
    <td>$Reserve->ReserveEmail</td>
    <td>$Reserve->TypePerson</td>
    <td>$Reserve->BadmintonCourt</td> 
    <td>$Reserve->TerminalGym</td> 
    <td>$Reserve->TimeStart</td> 
    <td>$Reserve->TimeFinish</td> 
    <td>$Reserve->BadmintonID</td> </tr>"; 
    
}
echo "</table>";
?>
<html>
<head></head>
<body>
    <!--เพิ่มการจอง [<a href=?controller=Reserve&action=newReserve>Click</a>]-->
</body>
</html>	


