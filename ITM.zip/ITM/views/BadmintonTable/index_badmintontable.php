<table border=1>
	<tr> <td>BadmintonID</td><td>BadmintonCourt</td><td>TerminalGym</td><td>TimeStart</td>
		<td>TimeFinish</td><td>Status</td></tr>

		<form method="get" action="">
	<input type="text" name="key">
	<input type="hidden" name="controller" value="BadmintonTable"/>
	<button type="submit" name="action" value="search">
Search</button>
</form>

<?php foreach($BadmintonTableList as $BadmintonTable)
{
	echo "
			<td>$BadmintonTable->BadmintonID </td>
			<td>$BadmintonTable->BadmintonCourt </td>
			<td>$BadmintonTable->TerminalGym </td>
			<td>$BadmintonTable->TimeStart </td>
			<td>$BadmintonTable->TimeFinish </td>
			<td>$BadmintonTable->StatusCourt  </td>
			<td><a href=?controller=Reserve&action=newReserve&BadmintonID=$BadmintonTable->BadmintonID>กดจอง</a></td></tr>";	
				
}
	echo "</table>";

	
	
?>

	

