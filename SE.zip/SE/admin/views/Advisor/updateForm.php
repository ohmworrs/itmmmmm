<form method="get" action="">
<label> AdvisorID<input type="int" name="AdvisorID"
value="<?php echo $Advisor->AdvisorID; ?>" /> </label><br>
<label>AdvisorName <input type="text" name="AdvisorName" 
value="<?php echo $Advisor->AdvisorName; ?>"/> </label><br>


<input type="hidden" name="controller" value="Advisor"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="update"> Save</button>

</form>