<html>
<head></head>
<body>
<form method="get" action="">

<label>เลขครุภัณฑร์ <input type="text" name="EquipmentID" 
    value="<?php echo $Equipment->EquipmentID;?>" /> </label><br>

<label>ชื่ออุปกรณ์<input type="text" name="EquipmentName" 
    value="<?php echo $Equipment->EquipmentName;?>"/> </label><br>
<label>รายละเอียด <input type="text" name="EquipmentDetail"
    value="<?php echo $Equipment->EquipmentDetail;?>"/> </label><br>

<label>ภาพอุปกรณ์<input type="text" name="EquipmentImage"
    value="<?php echo $Equipment->EquipmentImage;?>"/> </label><br>
<label>หมวดอุปกรณ์<input type="text" name="TypeID" 
    value="<?php echo $Equipment->TypeID;?>"/> </label><br>



<input type="hidden" name="controller" value="Equipment"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addEquipment" > Save</button>




</body>
</html>




