<table border=1>
	<tr> <td>TypeID</td><td>TypeName</td><td>อัพเดท</td><td>ลบ</td></tr>

		

<?php foreach($EquipmentTypeList as $EquipmentType)
{
	echo "
			<td>$EquipmentType->TypeID </td>
			<td>$EquipmentType->TypeName </td>
			<td><a href=?controller=EquipmentType&action=updateForm&TypeID=$EquipmentType->TypeID>updete</a></td>
            <td><a href=?controller=EquipmentType&action=deleteConfirm&TypeID=$EquipmentType->TypeID>dalete</a></td></tr>";	
				
}
	echo "</table>";

	
	
?>
<html>
<head>
	<title></title>
</head>
<body>
	<br>
	new EquipmentType <a href=?controller=EquipmentType&action=newEquipmentType>Click</a><br>
</body>
</html>
	

