
<form method="get" action="">

<label>TeacherName <input type="text" name="TeacherName" /> </label><br>
<label>Position <input type="text" name="Position" /> </label><br>

<input type="hidden" name="controller" value="Teacher"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addTeacher"> Save</button>

</form>



