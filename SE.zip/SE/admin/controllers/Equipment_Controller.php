<?php 
class EquipmentController
{
	public function index()
	{
		$EquipmentList=Equipment::getAll();
		require_once('views/Equipment/index_equipment.php');
	}

	public function newEquipment()
	{
		$EquipmentTypeList=EquipmentType::getAll();
		require_once('views/Equipment/newEquipment.php');
	}
	public function addEquipment()
	{
		$EquipmentID=$_GET['EquipmentID'];
		$EquipmentName=$_GET['EquipmentName'];
		$EquipmentDetail=$_GET['EquipmentDetail'];
		$EquipmentStatus=$_GET['EquipmentStatus'];
		$EquipmentImage=$_GET['EquipmentImage'];
		$TypeID=$_GET['TypeID'];
		echo $EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentImage,$TypeID;

		Equipment::add($EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentImage,$TypeID);
		EquipmentController::index();

	}

	public function search()
	{
		$key=$_GET['key'];
		$EquipmentList=Equipment::search($key);
		require_once('views/Equipment/index_equipment.php');
	}
	public function updateForm()
	{
		$EquipmentID=$_GET['EquipmentID'];
		$Equipment=Equipment::get($EquipmentID);
		$EquipmentList=Equipment::getAll();
		require_once('views/Equipment/updateForm.php');
	}
	public function update()
	{
		$EquipmentID=$_GET['EquipmentID'];
		$EquipmentName=$_GET['EquipmentName'];
		$EquipmentDetail=$_GET['EquipmentDetail'];
		$EquipmentStatus=$_GET['EquipmentStatus'];
		$EquipmentImage=$_GET['EquipmentImage'];
		$TypeID=$_GET['TypeID'];
		

		Equipment::update($EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentImage,$TypeID);
		EquipmentController::index();
	}
	public function deleteConfirm()
	{
		$EquipmentID=$_GET['EquipmentID'];
		$Equipment=Equipment::get($EquipmentID);
		require_once('views/Equipment/deleteConfirm.php');
	}
	public function delete()
	{
			$EquipmentID=$_GET['EquipmentID'];
			Equipment::delete($EquipmentID);
			EquipmentController::index();
	}
}?>