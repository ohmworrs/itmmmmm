<?php 
class EquipmentTypeController
{
	public function index()
	{
		$EquipmentTypeList=EquipmentType::getAll();
		require_once('views/EquipmentType/index_equipmenttype.php');
	}

	public function newEquipmentType()
	{
		$EquipmentTypeList=EquipmentType::getAll();
		require_once('views/EquipmentType/newEquipmentType.php');
	}
	public function addEquipmentType()
	{
		$TypeID=$_GET['TypeID'];
		$TypeName=$_GET['TypeName'];
	

		EquipmentType::add($TypeID,$TypeName);
		EquipmentTypeController::index();

	}

	public function search()
	{
		$key=$_GET['key'];
		$EquipmentTypeList=EquipmentType::search($key);
		require_once('views/EquipmentType/index_equipmenttype.php');
	}
	public function updateForm()
	{
		$TypeID=$_GET['TypeID'];
		$EquipmentType=EquipmentType::get($TypeID);
		
		require_once('views/EquipmentType/updateForm.php');
	}
	public function update()
	{
		$TypeID=$_GET['TypeID'];
		$TypeName=$_GET['TypeName'];
		
		
		EquipmentType::update($TypeID,$TypeName);
		EquipmentTypeController::index();
	}
	public function deleteConfirm()
	{
		$TypeID=$_GET['TypeID'];
		$EquipmentType=EquipmentType::get($TypeID);
		require_once('views/EquipmentType/deleteConfirm.php');
	}
	public function delete()
	{
			$TypeID=$_GET['TypeID'];
			EquipmentType::delete($TypeID);
			EquipmentTypeController::index();
	}

}?>