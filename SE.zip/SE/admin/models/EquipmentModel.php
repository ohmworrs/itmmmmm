<?php 
class Equipment{
	public $EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentImage,$TypeID;
	public function Equipment($EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentImage,$TypeID)
	{
		$this->EquipmentID = $EquipmentID;
		$this->EquipmentName = $EquipmentName;
		$this->EquipmentDetail = $EquipmentDetail;
		$this->EquipmentStatus = $EquipmentStatus;
		$this->EquipmentImage = $EquipmentImage;
		$this->TypeID = $TypeID;
	}

	public static function get($Code)
{
  require("connection_connect.php");
  
  $sql = "select *from Equipment where EquipmentID='$Code'";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $EquipmentID=$my_row['EquipmentID'];
  $EquipmentName=$my_row['EquipmentName'];
  $EquipmentDetail=$my_row['EquipmentDetail'];
  $EquipmentStatus=$my_row['EquipmentStatus'];
  $EquipmentImage=$my_row['EquipmentImage'];
  $TypeID=$my_row['TypeID'];
  require("connection_close.php");

  return new Equipment($EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentImage,$TypeID);
}
	public static function getAll()
	{
		$EquipmentList=[];
		require("connection_connect.php");
		$sql="select * from Equipment";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
			$EquipmentID=$my_row['EquipmentID'];
			$EquipmentName=$my_row['EquipmentName'];
			$EquipmentDetail=$my_row['EquipmentDetail'];
			$EquipmentStatus=$my_row['EquipmentStatus'];
			$EquipmentImage=$my_row['EquipmentImage'];
			$TypeID=$my_row['TypeID'];
			$EquipmentList[]=new Equipment($EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentImage,$TypeID);
		}
		require("connection_close.php");
		return $EquipmentList;
		
		
	}
	public static function search($key)
	{
		$EquipmentList=[];
		require_once("connection_connect.php");
		$sql="select *from Equipmentshoww
		where (EquipmentID like'%$key%' or EquipmentName like'%$key%' or EquipmentDetail like'%$key%' or EquipmentStatus like'%$key%' or EquipmentImage like'%$key%' or TypeID like'%$key%')";
		$result=$conn->query($sql);
		while ($my_row=$result->fetch_assoc())	
		{
			$EquipmentID=$my_row['EquipmentID'];
			$EquipmentName=$my_row['EquipmentName'];
			$EquipmentDetail=$my_row['EquipmentDetail'];
			$EquipmentStatus=$my_row['EquipmentStatus'];
			$EquipmentImage=$my_row['EquipmentImage'];
			$TypeID=$my_row['TypeID'];
			$EquipmentList[]=new Equipment($EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentImage,$TypeID);
		}
		require("connection_close.php");
		return $EquipmentList;

	}

	public static function add($EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentImage,$TypeID)
	{
		require("connection_connect.php");
		$sql="insert into Equipment (EquipmentID,EquipmentName,EquipmentDetail,EquipmentStatus,EquipmentImage,TypeID)
		values('$EquipmentID','$EquipmentName','$EquipmentDetail','$EquipmentStatus','$EquipmentImage','$TypeID')";
		$result=$conn->query($sql);
		echo $sql;
		require("connection_close.php");
		return "add success $result rows";
	}

	public static function update($EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentImage,$TypeID)
	{
	
		require("connection_connect.php");
		$sql="UPDATE Equipment SET EquipmentName = '$EquipmentName',EquipmentDetail = '$EquipmentDetail',EquipmentStatus = '$EquipmentStatus',EquipmentImage = '$EquipmentImage',TypeID = '$TypeID' WHERE EquipmentID = '$EquipmentID'";
		$result=$conn->query($sql);
		require("connection_close.php");
		return "update success $result row";
	}
	public static function delete($id)
	{
		require("connection_connect.php");
		$sql="Delete from Equipment	 where EquipmentID='$id'";
		$result=$conn->query($sql);
		require("connection_close.php");
		return "delete success $result row";
	}
}?>