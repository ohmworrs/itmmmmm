<?php session_start();  
require_once("connection_connect.php");

  $user_name = $_SESSION['username'];
  $name = $_SESSION['name'];
  $level = $_SESSION['level'];

 	if($level!='admin'){
    Header("Location: ../loginform.php");  
  }  
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="logout.php">
	<h1>ที่สุดเลยเว้ยแกก</h1>
	<h3> สวัสดี คุณ <?php echo $name; ?> สถานะ <?php echo $level; ?>  </h3>

	<input type="submit" value="ออกจากระบบ">
	</form>
</body>
</html>