<?php 
class TeacherApp{
	public $TeacherAppID,$ApproveEqID,$DateRecieve,$TeacherID;
	public function TeacherApp($TeacherAppID,$ApproveEqID,$DateRecieve,$TeacherID)
	{
		$this->TeacherAppID = $TeacherAppID;
		$this->ApproveEqID = $ApproveEqID;
		$this->DateRecieve = $DateRecieve;
		$this->TeacherID = $TeacherID;
	}

	public static function get($id)
{
  require("connection_connect.php");
  $sql = "select *from TeacherApp where TeacherAppID='$id'";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $TeacherAppID=$my_row['TeacherAppID$TeacherAppID'];
  $ApproveEqID=$my_row['ApproveEqID'];
  $DateRecieve=$my_row['DateRecieve'];
  $TeacherID=$my_row['TeacherID'];
 
  require("connection_close.php");

  return new TeacherApp($TeacherAppID,$ApproveEqID,$DateRecieve,$TeacherID);
}
	public static function getAll()
	{
		$TeacherAppList=[];
		require("connection_connect.php");
		$sql="select * from TeacherApp";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
			$TeacherAppID=$my_row['TeacherAppID'];
			$ApproveEqID=$my_row['ApproveEqID'];
			$DateRecieve=$my_row['DateRecieve'];
  			$TeacherID=$my_row['TeacherID'];
			
			$TeacherAppList[]=new TeacherApp($TeacherAppID,$ApproveEqID,$DateRecieve,$TeacherID);
		}
		require("connection_close.php");
		return $TeacherAppList;
		
		
	}
	public static function search($key)
	{
		$TeacherAppList=[];
		require_once("connection_connect.php");
		$sql="select *from TeacherApps
		where (TeacherAppID$TeacherAppID like'%$key%' or ApproveEqID like'%$key%')";
		$result=$conn->query($sql);
		while ($my_row=$result->fetch_assoc())	
		{
			$TeacherAppID=$my_row['TeacherAppID$TeacherAppID'];
			$ApproveEqID=$my_row['ApproveEqID'];
			$DateRecieve=$my_row['DateRecieve'];
 			 $TeacherID=$my_row['TeacherID'];
			
			$TeacherAppList[]=new TeacherApp($TeacherAppID,$ApproveEqID,$DateRecieve,$TeacherID);
		}
		require("connection_close.php");
		return $TeacherAppList;

	}
	public static function add($ApproveEqID,$DateRecieve,$TeacherID)
	{
		require("connection_connect.php");

    	$sql = "insert into TeacherApp(ApproveEqID,DateRecieve,TeacherID)
		values ('$ApproveEqID','$DateRecieve','$TeacherID')";
		$result=$conn->query($sql);
		
		$sql = "UPDATE view2 SET EquipmentStatus='อนุมัติแล้ว' where ApproveEquipmentID='$ApproveEqID'";
		$result=$conn->query($sql);

		$sql="DELETE from ApproveEquipment where ApproveEquipmentID='$ApproveEqID'";	
		$result=$conn->query($sql);
		echo $sql;

		require("connection_close.php");
		return "add success $result rows";
	}
}?>