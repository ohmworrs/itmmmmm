<table border=1>
	<tr> <td>Departmentcode</td><td>DepartmentName</td></tr>

		

<?php foreach($DepartmentList as $Department)
{
	echo "
			<td>$Department->DepartmentCode </td>
			<td>$Department->DepartmentName </td></td></tr>";	
				
}
	echo "</table>";

	
	
?>

	

