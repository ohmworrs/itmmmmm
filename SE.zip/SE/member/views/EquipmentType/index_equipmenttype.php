<table border=1>
	<tr> <td>TypeID</td><td>TypeName</td></tr>

		

<?php foreach($EquipmentTypeList as $EquipmentType)
{
	echo "
			<td>$EquipmentType->TypeID </td>
			<td>$EquipmentType->TypeName </td></td></tr>";	
				
}
	echo "</table>";

	
	
?>

	

