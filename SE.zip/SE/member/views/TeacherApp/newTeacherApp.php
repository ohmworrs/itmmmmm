<html>
<head></head>
<body>
<form method="get" action="">
<label>ApproveEqID <input type="int" name="ApproveEqID" readonly="true" 
    value="<?php echo $ApproveEquipment->ApproveEquipmentID;?>" /> </label><br>

<label>วันที่มารับ <input type="Date" name="DateRecieve"  /> </label><br>

<label>TeacherID <select name="TeacherID" >
    <?php foreach($TeacherList as $Teacher){
            echo "<option value=$Teacher->TeacherID";
            echo ">$Teacher->TeacherName</option>";
       
       
       }?> 
       </select></label><br>


<input type="hidden" name="controller" value="TeacherApp"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addTeacherApp" > Save</button>




</body>
</html>




