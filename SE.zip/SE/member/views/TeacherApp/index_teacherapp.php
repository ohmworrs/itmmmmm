<table border=1>
	<tr> <td>TeacherAppID</td><td>ApproveEqID</td><td>DateRecieve</td><td>TeacherID</td>
	</tr>

		

<?php foreach($TeacherAppList as $TeacherApp)
{
	echo "
			<td>$TeacherApp->TeacherAppID </td>
            <td>$TeacherApp->ApproveEqID </td>
            <td>$TeacherApp->DateRecieve </td>
			<td>$TeacherApp->TeacherID </td></tr>";
				
				
}
	echo "</table>";

	
	
?>

	

