<table border=1>
	<tr> <td>TeacherAppID</td><td>ApproveEqID</td><td>TeacherID</td><td>UserCode</td><td>EquipmentID</td><td>EquipmentName</td><td>DateBorrow</td><td>DateReturn</td><td>StatusReserve</td>
	</tr>

		

<?php foreach($TeacherAppList as $TeacherApp)
{
	echo "
			<td>$TeacherApp->TeacherAppID </td>
            <td>$TeacherApp->ApproveEqID </td>
			<td>$TeacherApp->TeacherID </td>
			<td>$TeacherApp->UserCode </td>
			<td>$TeacherApp->EquipmentID </td>
			<td>$TeacherApp->EquipmentName </td>
			<td>$TeacherApp->DateBorrow </td>
			<td>$TeacherApp->DateReturn </td>
			<td>$TeacherApp->StatusReserve </td></tr>";
				
				
}
	echo "</table>";

	
	
?>

	

