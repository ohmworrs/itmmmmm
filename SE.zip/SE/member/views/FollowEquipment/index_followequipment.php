<table border=1>
	<tr> <td>EquipmentID</td><td>EquipmentName</td><td>UserCode</td><td>EquipmentStatus</td>
		<td>Dateborrow</td><td>DateReturn</td></tr>

		

<?php foreach($FollowEquipmentList as $FollowEquipment)
{
	echo "
			<td>$FollowEquipment->EquipmentID </td>
			<td>$FollowEquipment->EquipmentName </td>
			<td>$FollowEquipment->UserCode </td>
			<td>$FollowEquipment->EquipmentStatus </td>
			<td>$FollowEquipment->DateBorrow </td>
			<td>$FollowEquipment->DateReturn  </td></tr>";
				
				
}
	echo "</table>";

	
	
?>

	

