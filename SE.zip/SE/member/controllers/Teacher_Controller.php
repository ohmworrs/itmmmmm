<?php 
class TeacherController
{
	public function index()
	{
		$TeacherList=Teacher::getAll();
		require_once('views/Teacher/index_teacher.php');
	}
}?>