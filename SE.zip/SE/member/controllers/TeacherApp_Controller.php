<?php 
class TeacherAppController
{
	public function index()
	{
		$TeacherAppList=TeacherApp::getAll();
		require_once('views/TeacherApp/index_teacherapp.php');
    }
    
    public function newTeacherApp ()
    {
		
		$id=$_GET['ApproveEquipmentID'];
		$ApproveEquipment = ApproveEquipment::get($id); 
		$ApproveEquipmentList = ApproveEquipment::getAll();
		$TeacherList=Teacher::getAll();
       
      
        require_once('views/TeacherApp/newTeacherApp.php');

    }

    public function addTeacherApp()
	{
		$ApproveEqID=$_GET['ApproveEqID'];
        $DateRecieve=$_GET['DateRecieve'];
		$TeacherID=$_GET['TeacherID'];
		

		TeacherApp::add($ApproveEqID,$DateRecieve,$TeacherID);
		TeacherAppController::index();
	
	}
	public function deleteConfirm()
	{
		$TeacherAppID=$_GET['TeacherAppID'];
		$TeacherApp=TeacherApp::get($TeacherAppID);
		require_once('views/TeacherApp/deleteConfirm.php');
	}
	public function delete()
	{
			$TeacherAppID=$_GET['TeacherAppID'];
			TeacherApp::delete($TeacherAppID);
			TeacherAppController::index();
	}


}?>