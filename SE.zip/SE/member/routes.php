<?php
$controllers=array('pages'=>['home','error'],
'Equipment'=>['index'],
'EquipmentType'=>['index'],
'UserMember'=>['index'],
'Department'=>['index'],
'EquipmentINCart'=>['index','newEquipmentINCart','addEquipmentINCart','deleteConfirm','delete'],
'Advisor'=>['index'],
'FollowEquipment'=>['index'],
'ApproveEquipment'=>['index','newApproveEquipment','addApproveEquipment','deleteConfirm','delete'],
'TeacherApp'=>['index','newTeacherApp','addTeacherApp'],
'Teacher'=>['index']);



function call($controller,$action){
	require_once("controllers/".$controller."_Controller.php");
	switch($controller)
	{
		case "pages"			: 		$controller = new PagesController();
					  					break;
		case "Equipment"		:		require_once("models/EquipmentModel.php");
										$controller = new EquipmentController();
										break;
		case "EquipmentType"	: 		require_once("models/EquipmentTypeModel.php");
										$controller = new EquipmentTypeController();
										break;
		case "UserMember"		: 		require_once("models/UserMemberModel.php");
										$controller = new UserMemberController();
										break;
		case "Department"		: 		require_once("models/DepartmentModel.php");
										$controller = new DepartmentController();
										break;
		case "EquipmentINCart"	: 		require_once("models/EquipmentINCartModel.php");
										require_once("models/UserMemberModel.php");
										require_once("models/EquipmentTypeModel.php");
										require_once("models/EquipmentModel.php");
										require_once("models/AdvisorModel.php");
										$controller = new EquipmentINCartController();
										break;
		case "Advisor"				: 	require_once("models/AdvisorModel.php");
										$controller = new AdvisorController();
										break;
		case "FollowEquipment"		: 	require_once("models/FollowEquipmentModel.php");
										$controller = new FollowEquipmentController();
										break;
		case "ApproveEquipment"		: 	require_once("models/ApproveEquipmentModel.php");
										require_once("models/EquipmentINCartModel.php");
										require_once("models/UserMemberModel.php");
										require_once("models/EquipmentModel.php");
										require_once("models/EquipmentTypeModel.php");
										require_once("models/AdvisorModel.php");
										$controller = new ApproveEquipmentController();
										break;
		case "TeacherApp"		: 		require_once("models/TeacherAppModel.php");
										require_once("models/TeacherModel.php");
										require_once("models/ApproveEquipmentModel.php");
										$controller = new TeacherAppController();
										break;
		case "Teacher"		: 			require_once("models/TeacherModel.php");
										$controller = new TeacherController();
										break;
		
		
								
	}
	$controller->{$action}();
}

if(array_key_exists($controller,$controllers))
{
	if(in_array($action,$controllers[$controller]))
	{
		call($controller,$action);
	}
	else
		call('pages','error');
}
else{
	call('pages','error');	
}
?>