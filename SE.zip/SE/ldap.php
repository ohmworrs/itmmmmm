<?php
session_start();
$ldap_error = array(	"ERR-000: OK",
						"ERR-001: Bind error",
						"ERR-002: Anonymous search failed",
						"ERR-003: User unknown",
						"ERR-004: More than one such user",
						"ERR-005: bind failed. user not authenticated.");

$ldap_uid			= "";
$ldap_first_name_eng= "";
$ldap_last_name_eng = "";
$ldap_first_name	= "";
$ldap_last_name		= "";
$ldap_email			= "";
$ldap_gender		= "";
$ldap_Job			= "";
$ldap_department	= "";
$ldap_faculty		= "";
$ldap_major_id		= "";
$ldap_campus		= "";		//รหัสวิทยาเขต ดังนี้ บางเขน=B , กำแพงแสน=K , ศรีราชา=S , สกลนคร=C
$ldap_idcode		= "";		//รหัสประจำตัวนิสิต


function user_authen($username, $ldappass) {
     $host1   = "ldap.ku.ac.th";
     $host2   = "ldap2.ku.ac.th";
     $host3   = "ldap3.ku.ac.th";
     $base_dn = "dc=ku,dc=ac,dc=th";

     $ldapserver = ldap_connect($host1);
	 if(!$ldapserver)
        {
                $ldapserver = ldap_connect($host2);
                if(!$ldapserver){
                $ldapserver = ldap_connect($host3);
                }
        }

		$bind = ldap_bind($ldapserver);
        if(!bind)
        {
               return(1);
        }

		$filter = "uid=" . $username;

        $result = ldap_search($ldapserver,$base_dn,$filter);
        $info = ldap_get_entries($ldapserver,$result);
        if(!$result)
        {
                return(2);
        }
        if($info["count"] == 0)
        {
                return(3);
        }
        if($info["count"] > 1)
        {
                return(4);
        }

		$user_dn = $info[0]["dn"];
        $bind = @ldap_bind($ldapserver,$user_dn,$ldappass);
        if(!$bind)
        {
                return(5);
        }
		
		
		require_once 'lib/configdb.inc';
        require_once 'adodb5/adodb.inc.php';
        require_once 'adodb5/drivers/adodb-mysql.inc.php';
        require_once 'lib/connectdb.inc.php';
		
       $rs = $conn->Execute("select * from users where username ='$username'"); 


		if($rs->RecordCount()<=0) {
			
	/*		
		 $conn->Execute("INSERT INTO users(username) VALUES('$username')"); //เพิ่มบัญชีผู้ใช้
		 
			 $rs2 = $conn->Execute("select * from users where username = '$username'"); 
			    $_SESSION['userid'] = $rs->fields['user_id'];
			  
			if($info[0]["position"][0]=="")  // นิสิต
			{
				
				   $rs = $conn->Execute("select * from student where name = '".$info[0]["first-name"][0]."' and surname = '".$info[0]["last-name"][0]."'");  
			
				  //ค้นหา userid
				   	
				   if($rs->RecordCount()<=0) //ตรวจสอบข้อมูลของนิสิต
				   {
				
				       $rs = $conn->Execute("select * from department where dept_code = '".$info[0]["major-id"][0]."'");  //ค้นหา dept_id
					   if($rs->RecordCount()<=0) //ไม่พบชื่อภาควิชาในระบบ
					   {
						    return(6);
					    }
					   $conn->Execute("INSERT INTO student(user_id,dept_id,name,surname,e_mail,student_code) VALUES('".$rs2->fields["user_id"]."','".$rs->fields["dept_id"]."','".$info[0]["first-name"][0]."','".$info[0]["last-name"][0]."','".$info[0]["mail"][0]."','".$info[0]["idcode"][0]."')");
				   }
				   else
				   {
					    $conn->Execute("UPDATE student SET  user_id='".$rs2->fields["user_id"]."' WHERE student_id ='".$rs->fields["student_id"]."'"); // อัพเดทข้อมูล userid
				   }
				   	  $_SESSION['author'] = "student";
		              $_SESSION['name'] = $info[0]["first-name"][0];
	 			      $_SESSION['surname'] =$info[0]["last-name"][0];
			
					   
				
			}
			else if($info[0]["position"][0]!=""&&$info[0]["advisor-id"][0]!="") // อาจารย์
			{
				
				
				 $rs = $conn->Execute("select * from teacher where name = '".$info[0]["first-name"][0]."' and surname = '".$info[0]["last-name"][0]."'");  
				 
				if($rs->RecordCount()<=0) //ตรวจสอบข้อมูลของอาจารย์
				{
					   $conn->Execute("INSERT INTO student(user_id,name,surname,e_mail,teacher_code) VALUES('".$rs2->fields["user_id"]."','".$info[0]["first-name"][0]."','".$info[0]["last-name"][0]."','".$info[0]["mail"][0]."','".$info[0]["advisor-id"][0]."')");
				 }
				 else
				 {
					    $conn->Execute("UPDATE teacher SET  user_id='".$rs2->fields["user_id"]."' WHERE teacher_id ='".$rs->fields["teacher_id"]."'"); // อัพเดทข้อมูล userid
			     }
				   	  $_SESSION['author'] = "teacher";
		             $_SESSION['name'] = $info[0]["first-name"][0];
	 			      $_SESSION['surname'] =$info[0]["last-name"][0];
				 
				 
						
				
			}
     			*/
	
		}	
		else {
			            $_SESSION['userid'] = $rs->fields['user_id'];
						   $_SESSION['data_type']='';
						
						$rs_teacher = $conn->Execute("select * from teacher where user_id = '".$rs->fields['user_id']."'");  //ค้นหา dept_id
						$rs_student = $conn->Execute("select * from student where user_id = '".$rs->fields['user_id']."'"); 
						$rs_managertable =  $conn->Execute("select * from managertable where user_id = '".$rs->fields['user_id']."'");
						$rs_admin =  $conn->Execute("select * from admin where user_id = '".$rs->fields['user_id']."'");
						$count_type=0;
			  			if($rs_student->RecordCount()>0)  // นิสิต
		             	{
				                    $_SESSION['data_type'] =  $_SESSION['data_type'].",student";
									  $_SESSION['author'] = "student";
									  $_SESSION['name'] = $info[0]["first-name"][0];
	 			                      $_SESSION['surname'] =$info[0]["last-name"][0];
							
					   $count_type++;
				
						}
						if($rs_teacher->RecordCount()>0)  // อาจารย์
						{
				 $_SESSION['data_type'] =  $_SESSION['data_type'].",teacher";
				
									  $_SESSION['author'] = "teacher";
									  $_SESSION['name'] = $info[0]["first-name"][0];
	 			                      $_SESSION['surname'] =$info[0]["last-name"][0];
									     $count_type++;

			            }
						if($rs_managertable->RecordCount()>0){
								 $_SESSION['data_type'] =  $_SESSION['data_type'].",".$rs_managertable->fields["types"];
							          $_SESSION['author'] = $rs_managertable->fields["types"];
									  $_SESSION['name'] = $info[0]["first-name"][0];
	 			                      $_SESSION['surname'] =$info[0]["last-name"][0];
									  
									  $rs_dept = $conn->Execute("select * from department where  dept_id ='".$rs_managertable->fields["dept_id"]."'");
									  $_SESSION['d'] = $rs_dept->fields['dept_name'];
									  $_SESSION['d_id'] = $rs_dept->fields['dept_id'];
									     $count_type++;
							
						}
						if($rs_admin->RecordCount()>0){
							 $_SESSION['data_type'] =  $_SESSION['data_type'].",admin";
							     $_SESSION['author'] = "admin";
		  				         $_SESSION['name'] = $info[0]["first-name"][0];
	 			                 $_SESSION['surname'] =$info[0]["last-name"][0];
								    $count_type++;
								  
						}
		}
       /* $GLOBALS["ldap_uid"]		= $info[0]["uid"][0];
        $GLOBALS["ldap_first_name_eng"]	= $info[0]["givenname"][0] ;
		$GLOBALS["ldap_last_name_eng"]	=$info[0]["sn"][0];
        $GLOBALS["ldap_first_name"]	= $info[0]["first-name"][0];
		$GLOBALS["ldap_last_name"]	= $info[0]["last-name"][0];
        $GLOBALS["ldap_email"]		= $info[0]["mail"][0];
        $GLOBALS["ldap_gender"]		= $info[0]["gender"][0];
        $GLOBALS["ldap_major_id"]   = $info[0]["major-id"][0];
		$GLOBALS["ldap_idcode"]		= $info[0]["idcode"][0];
		
        $GLOBALS["ldap_faculty"]	= $info[0]["faculty"][0];
        $GLOBALS["ldap_campus"]		= $info[0]["campus"][0];
        $GLOBALS["ldap_Job"]		= $info[0]["jobdescription"][0];*/

      $_SESSION['count_type'] =  $count_type;
		ldap_close($ldapserver);

        return(0);

}

?>