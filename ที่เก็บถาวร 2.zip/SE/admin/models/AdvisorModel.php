<?php 
class Advisor{
	public $AdvisorID,$AdvisorName;
	public function Advisor($AdvisorID,$AdvisorName)
	{
		$this->AdvisorID = $AdvisorID;
		$this->AdvisorName = $AdvisorName;
		
	}

	public static function get($id)
{
  require("connection_connect.php");
  $sql = "select *from Advisor where AdvisorID='$id'";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $AdvisorID=$my_row['AdvisorID'];
  $AdvisorName=$my_row['AdvisorName'];
 
  require("connection_close.php");

  return new Advisor($AdvisorID,$AdvisorName);
}
	public static function getAll()
	{
		$AdvisorList=[];
		require("connection_connect.php");
		$sql="select * from Advisor";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
			$AdvisorID=$my_row['AdvisorID'];
			$AdvisorName=$my_row['AdvisorName'];
			
			$AdvisorList[]=new Advisor($AdvisorID,$AdvisorName);
		}
		require("connection_close.php");
		return $AdvisorList;
		
		
	}
	public static function search($key)
	{
		$AdvisorList=[];
		require_once("connection_connect.php");
		$sql="select *from Advisors
		where (AdvisorID like'%$key%' or AdvisorName like'%$key%')";
		$result=$conn->query($sql);
		while ($my_row=$result->fetch_assoc())	
		{
			$AdvisorID=$my_row['AdvisorID'];
			$AdvisorName=$my_row['AdvisorName'];
			
			$AdvisorList[]=new Advisor($AdvisorID,$AdvisorName);
		}
		require("connection_close.php");
		return $AdvisorList;

	}

	public static function add($AdvisorName)
	{
		require("connection_connect.php");
		$sql="insert into Advisor (AdvisorName)
		values('$AdvisorName')";
		$result=$conn->query($sql);
		require("connection_close.php");
		return "add success $result rows";
	}

	public static function update($AdvisorID,$AdvisorName)
	{
	
		require("connection_connect.php");
		$sql="UPDATE Advisor SET AdvisorName = '$AdvisorName' WHERE AdvisorID = '$AdvisorID'";
		$result=$conn->query($sql);
		require("connection_close.php");
		return "update success $result row";
	}
	public static function delete($id)
	{
		require("connection_connect.php");
		$sql="Delete from Advisor	 where AdvisorID='$id'";
		$result=$conn->query($sql);
		require("connection_close.php");
		return "delete success $result row";
	}
}?>