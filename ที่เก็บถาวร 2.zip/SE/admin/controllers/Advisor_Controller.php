<?php 
class AdvisorController
{
	public function index()
	{
		$AdvisorList=Advisor::getAll();
		require_once('views/Advisor/index_advisor.php');
	}
	public function newAdvisor()
	{
		$AdvisorList=Advisor::getAll();
		require_once('views/Advisor/newAdvisor.php');
	}
	public function addAdvisor()
	{
		
		$AdvisorName=$_GET['AdvisorName'];
	

		Advisor::add($AdvisorName);
		AdvisorController::index();

	}

	public function search()
	{
		$key=$_GET['key'];
		$AdvisorList=Advisor::search($key);
		require_once('views/Advisor/index_advisor.php');
	}
	public function updateForm()
	{
		$AdvisorID=$_GET['AdvisorID'];
		$Advisor=Advisor::get($AdvisorID);
		$AdvisorList=Advisor::getAll();
		require_once('views/Advisor/updateForm.php');
	}
	public function update()
	{
		$AdvisorID=$_GET['AdvisorID'];
		$AdvisorName=$_GET['AdvisorName'];
		

		Advisor::update($AdvisorID,$AdvisorName);
		AdvisorController::index();
	}
	public function deleteConfirm()
	{
		$AdvisorID=$_GET['AdvisorID'];
		$Advisor=Advisor::get($AdvisorID);
		require_once('views/Advisor/deleteConfirm.php');
	}
	public function delete()
	{
			$AdvisorID=$_GET['AdvisorID'];
			Advisor::delete($AdvisorID);
			AdvisorController::index();
	}


}?>