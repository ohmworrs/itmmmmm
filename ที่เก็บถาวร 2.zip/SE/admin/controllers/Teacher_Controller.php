<?php 
class TeacherController
{
	public function index()
	{
		$TeacherList=Teacher::getAll();
		require_once('views/Teacher/index_teacher.php');
	}

	public function newTeacher()
	{
		$TeacherList=Teacher::getAll();
		require_once('views/Teacher/newTeacher.php');
	}
	public function addTeacher()
	{
		
		$TeacherName=$_GET['TeacherName'];
		$Position=$_GET['Position'];

		Teacher::add($TeacherName,$Position);
		TeacherController::index();

	}

	public function search()
	{
		$key=$_GET['key'];
		$TeacherList=Teacher::search($key);
		require_once('views/Teacher/index_teacher.php');
	}
	public function updateForm()
	{
		$TeacherID=$_GET['TeacherID'];
		$Teacher=Teacher::get($TeacherID);
		$TeacherList=Teacher::getAll();
		require_once('views/Teacher/updateForm.php');
	}
	public function update()
	{
		$TeacherID=$_GET['TeacherID'];
		$TeacherName=$_GET['TeacherName'];
		$Position=$_GET['Position'];

		Teacher::update($TeacherID,$TeacherName,$Position);
		TeacherController::index();
	}
	public function deleteConfirm()
	{
		$TeacherID=$_GET['TeacherID'];
		$Teacher=Teacher::get($TeacherID);
		require_once('views/Teacher/deleteConfirm.php');
	}
	public function delete()
	{
			$TeacherID=$_GET['TeacherID'];
			Teacher::delete($TeacherID);
			TeacherController::index();
	}




}?>