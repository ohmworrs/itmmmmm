<table border=1>
	<tr> <td>PersonnelEqID</td><td>PersonnelName</td><td>EquipmentID</td><td>EquipmentName</td><td>DateBorrow</td><td>DateReturn</td>
	</tr>

		

<?php foreach($PersonnelEqList as $PersonnelEq)
{
	echo "
			<td>$PersonnelEq->PersonnelEqID </td>
            <td>$PersonnelEq->PersonnelName </td>
			<td>$PersonnelEq->EquipmentID </td>
			<td>$PersonnelEq->EquipmentName </td>
			<td>$PersonnelEq->DateBorrow </td>
			<td>$PersonnelEq->DateReturn </td></tr>";
				
				
}
	echo "</table>";

	
	
?>

	

