<table border=1>
	<tr> <td>EquipmentID</td><td>EquipmentName</td><td>EquipmentDetail</td><td>EquipmentStatus</td>
		<td>EquipmentImage</td><td>TypeID</td><td>อัพเดท</td><td>ลบ</td><td>กดยืม</td></tr>

		

<?php foreach($EquipmentList as $Equipment)
{
	echo "
			<td>$Equipment->EquipmentID </td>
			<td>$Equipment->EquipmentName </td>
			<td>$Equipment->EquipmentDetail </td>
			<td>$Equipment->EquipmentStatus </td>
			<td>$Equipment->EquipmentImage </td>
			<td>$Equipment->TypeID  </td>
			<td><a href=?controller=Equipment&action=updateForm&EquipmentID=$Equipment->EquipmentID&>อัพเดท</a></td>
			<td><a href=?controller=Equipment&action=deleteConfirm&EquipmentID=$Equipment->EquipmentID&>ลบ</a></td>
			<td><a href=?controller=PersonnelEq&action=newPersonnelEq&EquipmentID=$Equipment->EquipmentID&>กดเลือก</a></td></tr>";
				
				
}
	echo "</table>";

	
	
?>

<html>
<head>
	<title></title>
</head>
<body>
	<br>
	new Equipment <a href=?controller=Equipment&action=newEquipment>Click</a><br>
	การคืนอุปกรณ์ <a href=?controller=Equipment&action=EquipmentReturnForm>Click</a><br>
</body>
</html>

	

