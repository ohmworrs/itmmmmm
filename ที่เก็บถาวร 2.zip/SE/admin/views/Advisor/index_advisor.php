<table border=1>
	<tr> <td>AdvisorID</td><td>AdvisorName</td><td>อัพเดท</td><td>ลบ</td></tr>

		

<?php foreach($AdvisorList as $Advisor)
{
	echo "
			<td>$Advisor->AdvisorID </td>
			<td>$Advisor->AdvisorName </td>
			<td><a href=?controller=Advisor&action=updateForm&AdvisorID=$Advisor->AdvisorID>updete</a></td>
            <td><a href=?controller=Advisor&action=deleteConfirm&AdvisorID=$Advisor->AdvisorID>dalete</a></td></tr>";	
				
}
	echo "</table>";

	
	
?>
<html>
<head>
	<title></title>
</head>
<body>
	<br>
	new Advisor <a href=?controller=Advisor&action=newAdvisor>Click</a><br>
</body>
</html>


	

