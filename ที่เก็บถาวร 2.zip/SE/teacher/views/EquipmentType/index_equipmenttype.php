<table border=1>
	<tr> <td>TypeID</td><td>TypeName</td></tr>

		

<?php foreach($EquipmentTypeList as $EquipmentType)
{
	echo "
			<td>$EquipmentType->TypeID </td>
			<td>$EquipmentType->TypeName </td></tr>";	
				
}
	echo "</table>";

	
	
?>
<html>
<head>
	<title></title>
</head>
<body>
	<br>
	
</body>
</html>
	

