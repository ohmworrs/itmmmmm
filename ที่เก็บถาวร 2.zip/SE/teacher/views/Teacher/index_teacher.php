<table border=1>
	<tr> <td>TeacherID</td><td>TeacherName</td><td>Position</td></tr>

		

<?php foreach($TeacherList as $Teacher)
{
	echo "  <td>$Teacher->TeacherID </td>
            <td>$Teacher->TeacherName </td>
            <td>$Teacher->Position </td>
           </tr>";			
}
    echo "</table>";
?>

<html>
<head>
	<title></title>
</head>
<body>
	<br>
	
</body>
</html>

