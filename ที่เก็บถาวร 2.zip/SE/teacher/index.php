<?php session_start();  
require_once("connection_connect.php");

  $user_name = $_SESSION['username'];
  $name = $_SESSION['name'];
  $level = $_SESSION['level'];

 	if($level!='teacher'){
    Header("Location: ../loginform.php");  
  }  
?>
<!DOCTYPE html>
<html>
<head>
  				
	<title></title>
</head>
<body>
	<form action="logout.php">
	<h1>ที่สุดเลยเว้ยแกก</h1>
	<h3> สวัสดี คุณ <?php echo $name; ?> สถานะ <?php echo $level; ?>  </h3>

	<input type="submit" value="ออกจากระบบ">
	</form>
</body>
</html>

<?php

//error_reporting (E_ALL ^ E_NOTICE);	

if (isset($_GET['controller'])&&isset($_GET['action']))
{
	$controller = $_GET['controller'];
	$action = $_GET['action'];
}
else 
{
	$controller = 'pages';
	$action = 'home';
}?>
<html>

<head></head>
			

<body>
		<center>
	
	
			  	[<a href='index.php'>Home</a>]
				[<a href='?controller=Advisor&action=index'>อาจารย์ที่ปรึกษาโครงการ</a>]
				[<a href='?controller=Teacher&action=index'>อาจารย์ที่ปรึกษา</a>]
				[<a href='?controller=TeacherApp&action=index'>ติดตามสถานะการจอง</a>]
				[<a href='?controller=EquipmentType&action=index'>หมวดหมู่อุปกรณ์</a>]<br>
				[<a href='?controller=Equipment&action=index'>อุปกรณ์</a>]
				
				[<a href='?controller=ApproveEquipment&action=index'>ส่งให้จารย์</a>]
				[<a href='?controller=TeacherApp&action=index'>เช็คสถานะ</a>]
				[<a href='?controller=PersonnelEq&action=index'>การยืมของบุคลากร</a>]
				
				
			<br>
		
  

			<br>
</body>	
	 
	 	<?php require_once("routes.php");?> 

	
</div>
	

</html>	