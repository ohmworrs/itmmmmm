<?php 
session_start();
        if(isset($_POST['username'])){
                  require_once("connection_connect.php");
                  $user_name = $_POST['username'];
                  $password = $_POST['password'];
					echo "$user_name";
					echo "$password";
                  $sql="SELECT * FROM login 
                  WHERE  username='".$user_name."' 
                  AND  password='".$password."' ";
                  $result = mysqli_query($conn,$sql);
				
                  if(mysqli_num_rows($result)==1){
                      $row = mysqli_fetch_array($result);

                      $_SESSION["username"] = $row["username"];
                      $_SESSION["name"] = $row["name"];
                      $_SESSION["level"] = $row["level"];

                      if($_SESSION["level"]=="admin"){ 
                      
                        Header("Location: ./admin/index.php");
                      }
                  if ($_SESSION["level"]=="member"){ 
                     
                        Header("Location: ./member/index.php");
                      }
                      if ($_SESSION["level"]=="teacher"){ 
                     
                        Header("Location: ./teacher/index.php");
                      }
                  }else{
                    echo "<script>";
                        echo "alert(\" user หรือ  password ไม่ถูกต้อง\");"; 
                        echo "window.history.back()";
                    echo "</script>";
 
                  }
        }else{

             Header("Location: loginform.php"); //user & password incorrect back to login again
 
        }
?>