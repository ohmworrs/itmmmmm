<?php 
class EquipmentTypeController
{
	public function index()
	{
		$EquipmentTypeList=EquipmentType::getAll();
		require_once('views/EquipmentType/index_equipmenttype.php');
	}
}?>