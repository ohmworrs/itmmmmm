<?php 
class ApproveEquipmentController
{
	public function index()
	{
		$ApproveEquipmentList=ApproveEquipment::getAll();
		require_once('views/ApproveEquipment/index_approveequipment.php');
    }
    
    public function newApproveEquipment ()
    {
		
		$id=$_GET['EquipmentINCartID'];
		$EquipmentINCart = EquipmentINCart::get($id); 
		$AdvisorList = Advisor::getAll();
		$EquipmenINCartList = EquipmentINCart::getAll();
        $EquipmentList=Equipment::getAll();
        $EquipmentTypeList=EquipmentType::getAll();
        $UserMemberList=UserMember::getAll();
        require_once('views/ApproveEquipment/newApproveEquipment.php');

    }

    public function addApproveEquipment()
	{
		$EquipmentINCartID=$_GET['EquipmentINCartID'];
        $UserCode=$_GET['UserCode'];
		$EquipmentID=$_GET['EquipmentID'];
		$EquipmentName=$_GET['EquipmentName'];
		$EquipmentDetail=$_GET['EquipmentDetail'];
		$EquipmentImage=$_GET['EquipmentImage'];
		$TypeID=$_GET['TypeID'];
		$DateBorrow=$_GET['DateBorrow'];
		$DateReturn=$_GET['DateReturn'];
		$Reason=$_GET['Reason'];
		$AdvisorID=$_GET['AdvisorID'];
		
		ApproveEquipment::add($EquipmentINCartID,$UserCode,$EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentImage,$TypeID,$DateBorrow,$DateReturn,$Reason,$AdvisorID);
		ApproveEquipmentController::index();
	
	}
	public function deleteConfirm()
	{
		$ApproveEquipmentID=$_GET['ApproveEquipmentID'];
		$ApproveEquipment=ApproveEquipment::get($ApproveEquipmentID);
		require_once('views/ApproveEquipment/deleteConfirm.php');
	}
	public function delete()
	{
			$ApproveEquipmentID=$_GET['ApproveEquipmentID'];
			ApproveEquipment::delete($ApproveEquipmentID);
			ApproveEquipmentController::index();
	}


}?>