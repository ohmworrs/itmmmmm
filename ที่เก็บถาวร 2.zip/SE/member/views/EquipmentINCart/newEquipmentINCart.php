<html>
<head></head>
<body>
<form method="get" action="">
<label>รหัสนิสิต <input type="text" name="UserCode" /> </label><br>

<label>เลขครุภัณฑร์ <input type="text" name="EquipmentID" readonly="true" 
    value="<?php echo $Equipment->EquipmentID;?>" /> </label><br>

<label>ชื่ออุปกรณ์<input type="text" name="EquipmentName" readonly="true" 
    value="<?php echo $Equipment->EquipmentName;?>"/> </label><br>
<label>รายละเอียด <input type="text" name="EquipmentDetail"readonly="true" 
    value="<?php echo $Equipment->EquipmentDetail;?>"/> </label><br>

<label>ภาพอุปกรณ์<input type="text" name="EquipmentImage" readonly="true" 
    value="<?php echo $Equipment->EquipmentImage;?>"/> </label><br>
<label>หมวดอุปกรณ์<input type="text" name="TypeID" readonly="true" 
    value="<?php echo $Equipment->TypeID;?>"/> </label><br>
<label>วันที่มายืมอุปกรณ์ <input type="Date" name="DateBorrow" /> </label><br>

<label>วันที่คืนอุปกรณ์ <input type="Date" name="DateReturn" /> </label><br>
<label>เหตุผลที่ยืม<input type="text" name="Reason" /> </label><br>

<label>อาจารย์ที่ปรึกษาโครงงาน<select name="AdvisorID">
        <?php foreach($AdvisorList as $Advisor){
            echo "<option value=$Advisor->AdvisorID";
         
            echo "> $Advisor->AdvisorName</option<br>";
        }?>
</select></label><br>


<input type="hidden" name="controller" value="EquipmentINCart"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addEquipmentINCart" > Save</button>




</body>
</html>




