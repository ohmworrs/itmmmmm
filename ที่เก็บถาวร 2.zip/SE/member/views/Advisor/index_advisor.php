<table border=1>
	<tr> <td>AdvisorID</td><td>AdvisorName</td></tr>

		

<?php foreach($AdvisorList as $Advisor)
{
	echo "
			<td>$Advisor->AdvisorID </td>
			<td>$Advisor->AdvisorName </td></td></tr>";	
				
}
	echo "</table>";

	
	
?>

	

