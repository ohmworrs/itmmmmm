<html>
<head></head>
<body>
<form method="get" action="">
<label>ApproveEqID <input type="int" name="ApproveEqID" readonly="true" 
    value="<?php echo $ApproveEquipment->ApproveEquipmentID;?>" /> </label><br>



<label>TeacherID <select name="TeacherID" >
    <?php foreach($TeacherList as $Teacher){
            echo "<option value=$Teacher->TeacherID";
            echo ">$Teacher->TeacherName</option>";
       
       }?> 
       </select></label><br>
       <label>UserCode <input type="text" name="UserCode" readonly="true" 
    value="<?php echo $ApproveEquipment->UserCode;?>" /> </label><br>

    <label>EquipmentID <input type="text" name="EquipmentID" readonly="true" 
    value="<?php echo $ApproveEquipment->EquipmentID;?>" /> </label><br>

    <label>EquipmentName <input type="text" name="EquipmentName" readonly="true" 
    value="<?php echo $ApproveEquipment->EquipmentName;?>" /> </label><br>

    <label>DateBorrow <input type="int" name="DateBorrow" readonly="true" 
    value="<?php echo $ApproveEquipment->DateBorrow;?>" /> </label><br>

    <label>DateReturn <input type="int" name="DateReturn" readonly="true" 
    value="<?php echo $ApproveEquipment->DateReturn;?>" /> </label><br>

<label>สถานะ<select name="StatusReserve">
       <?php    echo "<option value=''></option>";
                echo "<option value='ไม่อนุมัติ'>ไม่อนุมัติ</option>"; 
                echo "<option value='อนุมัติ'>อนุมัติ</option>";  ?>

</select></label><br>

<input type="hidden" name="controller" value="TeacherApp"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addTeacherApp" > Save</button>




</body>
</html>




