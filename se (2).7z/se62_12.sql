-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2020 at 04:15 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se62_12`
--

-- --------------------------------------------------------

--
-- Table structure for table `advisor`
--

CREATE TABLE `advisor` (
  `AdvisorID` int(4) NOT NULL,
  `AdvisorName` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `advisor`
--

INSERT INTO `advisor` (`AdvisorID`, `AdvisorName`) VALUES
(1, 'โออิชิ เคียวโฮ'),
(2, 'อิชิตัน กรีนที');

-- --------------------------------------------------------

--
-- Table structure for table `approveequipment`
--

CREATE TABLE `approveequipment` (
  `ApproveEquipmentID` int(11) NOT NULL,
  `EquipmentINCartID` int(11) NOT NULL,
  `UserCode` varchar(15) NOT NULL,
  `EquipmentID` varchar(40) NOT NULL,
  `EquipmentName` varchar(30) NOT NULL,
  `EquipmentDetail` varchar(40) NOT NULL,
  `EquipmentImage` varchar(19) NOT NULL,
  `TypeID` varchar(5) NOT NULL,
  `DateBorrow` date NOT NULL,
  `DateReturn` date NOT NULL,
  `Reason` varchar(40) NOT NULL,
  `AdvisorID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `DepartmentCode` varchar(10) NOT NULL,
  `DepartmentName` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`DepartmentCode`, `DepartmentName`) VALUES
('E29', 'ภาควิชาวิศวกรรมคอมพิวเตอร์');

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `EquipmentID` varchar(30) NOT NULL,
  `EquipmentName` varchar(30) NOT NULL,
  `EquipmentDetail` varchar(30) NOT NULL,
  `EquipmentStatus` varchar(30) NOT NULL,
  `EquipmentImage` varchar(30) NOT NULL,
  `TypeID` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`EquipmentID`, `EquipmentName`, `EquipmentDetail`, `EquipmentStatus`, `EquipmentImage`, `TypeID`) VALUES
('1002003000', 'aaaaa', 'aaaaa', 'พร้อมใช้งาน', 'aaaaa', 'EH'),
('3001002000', 'แผ่นลงไดร์เวอร์', 'ลงไดร์เวอร์ให้กับคอมพิวเตอร์', 'ไม่พร้อมใช้งาน', 'Driver.jpeg', 'ES');

-- --------------------------------------------------------

--
-- Table structure for table `equipmentincart`
--

CREATE TABLE `equipmentincart` (
  `EquipmentINCartID` int(11) NOT NULL,
  `UserCode` varchar(15) NOT NULL,
  `EquipmentID` varchar(30) NOT NULL,
  `EquipmentName` varchar(30) NOT NULL,
  `EquipmentDetail` varchar(50) NOT NULL,
  `EquipmentImage` varchar(40) NOT NULL,
  `TypeID` varchar(11) NOT NULL,
  `DateBorrow` date NOT NULL,
  `DateReturn` date NOT NULL,
  `Reason` text NOT NULL,
  `AdvisorID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `equipmentincart`
--

INSERT INTO `equipmentincart` (`EquipmentINCartID`, `UserCode`, `EquipmentID`, `EquipmentName`, `EquipmentDetail`, `EquipmentImage`, `TypeID`, `DateBorrow`, `DateReturn`, `Reason`, `AdvisorID`) VALUES
(134, 'b6020552004', '1002003000', 'aaaaa', 'aaaaa', 'aaaaa', 'EH', '2020-03-26', '2020-03-27', 'asd', 1),
(135, 'b6020552004', '1002003000', 'aaaaa', 'aaaaa', 'aaaaa', 'EH', '2020-03-26', '2020-03-27', 'asd', 1),
(136, 'b6020552004', '1002003000', 'aaaaa', 'aaaaa', 'aaaaa', 'EH', '2020-03-26', '2020-03-27', 'asd', 1),
(137, 'b6020552004', '1002003000', 'aaaaa', 'aaaaa', 'aaaaa', 'EH', '2020-03-26', '2020-03-27', 'asd', 1),
(138, 'b6020552004', '1002003000', 'aaaaa', 'aaaaa', 'aaaaa', 'EH', '2020-03-26', '2020-03-27', 'asd', 1),
(139, 'b6020552004', '1002003000', 'aaaaa', 'aaaaa', 'aaaaa', 'EH', '2020-03-26', '2020-03-27', 'asd', 1),
(140, 'b6020552004', '1002003000', 'aaaaa', 'aaaaa', 'aaaaa', 'EH', '2020-03-26', '2020-03-27', 'asd', 1);

-- --------------------------------------------------------

--
-- Table structure for table `equipmenttype`
--

CREATE TABLE `equipmenttype` (
  `TypeID` varchar(30) NOT NULL,
  `TypeName` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `equipmenttype`
--

INSERT INTO `equipmenttype` (`TypeID`, `TypeName`) VALUES
('EH', 'อุปกรณ์ฮาร์ดแวร์'),
('EN', 'อุปกรณ์เน็ตเวิร์ค'),
('ES', 'อุปกรณ์ซอฟต์แวร์');

-- --------------------------------------------------------

--
-- Stand-in structure for view `followequipment`
-- (See below for the actual view)
--
CREATE TABLE `followequipment` (
`EquipmentID` varchar(30)
,`EquipmentName` varchar(30)
,`UserCode` varchar(15)
,`EquipmentStatus` varchar(30)
,`DateBorrow` date
,`DateReturn` date
);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `level` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `name`, `level`) VALUES
('admin', 'admin', 'admin', 'admin'),
('b6020552004', '1234', 'Worrasak Khammuang', 'member'),
('member', 'member', 'member', 'member'),
('teacher', 'teacher', 'teacher', 'teacher');

-- --------------------------------------------------------

--
-- Table structure for table `personneleq`
--

CREATE TABLE `personneleq` (
  `PersonnelEqID` int(11) NOT NULL,
  `PersonnelName` varchar(40) NOT NULL,
  `EquipmentID` varchar(30) NOT NULL,
  `EquipmentName` varchar(30) NOT NULL,
  `DateBorrow` date NOT NULL,
  `DateReturn` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `personneleq`
--

INSERT INTO `personneleq` (`PersonnelEqID`, `PersonnelName`, `EquipmentID`, `EquipmentName`, `DateBorrow`, `DateReturn`) VALUES
(1, 'sad   happy', '1002003000', 'โน้ตบุค', '2020-03-26', '2020-03-27'),
(2, 'aaaa', '1002003000', 'aaaaa', '2020-03-27', '2020-03-27'),
(3, 'aaaa', '1002003000', 'aaaaa', '2020-03-25', '2020-03-24'),
(4, 'AsssA', '3001002000', 'แผ่นลงไดร์เวอร์', '2020-03-26', '2020-03-27'),
(5, 'AsssA', '3001002000', 'แผ่นลงไดร์เวอร์', '2020-03-26', '2020-03-27');

-- --------------------------------------------------------

--
-- Table structure for table `statusreserve`
--

CREATE TABLE `statusreserve` (
  `StatusReserveID` int(11) NOT NULL,
  `EquipmentID` varchar(15) NOT NULL,
  `EquipmentName` varchar(30) NOT NULL,
  `UserCode` varchar(15) NOT NULL,
  `DateBorrow` date NOT NULL,
  `DateReturn` date NOT NULL,
  `StatusReserve` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `TeacherID` int(11) NOT NULL,
  `TeacherName` varchar(40) NOT NULL,
  `Position` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`TeacherID`, `TeacherName`, `Position`) VALUES
(1, 'วันเฉลิม ทูเฉลิม', 'ศาสตราจารย์'),
(2, 'โอริโอ้ ชาเขียวเย็น', 'ศาสตราจารย์');

-- --------------------------------------------------------

--
-- Table structure for table `teacherapp`
--

CREATE TABLE `teacherapp` (
  `TeacherAppID` int(11) NOT NULL,
  `ApproveEqID` int(11) NOT NULL,
  `TeacherID` int(40) NOT NULL,
  `UserCode` varchar(15) NOT NULL,
  `EquipmentID` varchar(15) NOT NULL,
  `EquipmentName` varchar(45) NOT NULL,
  `DateBorrow` date NOT NULL,
  `DateReturn` date NOT NULL,
  `StatusReserve` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teacherapp`
--

INSERT INTO `teacherapp` (`TeacherAppID`, `ApproveEqID`, `TeacherID`, `UserCode`, `EquipmentID`, `EquipmentName`, `DateBorrow`, `DateReturn`, `StatusReserve`) VALUES
(12, 13, 1, '1234456789', '11111111', 'โคอาล่า', '0000-00-00', '0000-00-00', 'อนุมัติแล้ว'),
(13, 13, 1, '1234456789', '111111', 'โคอาล่า', '0000-00-00', '0000-00-00', 'ไม่อนุมัติ'),
(14, 14, 1, '1234456789', '1111111', 'โคอาล่า', '0000-00-00', '0000-00-00', 'ไม่อนุมัติ'),
(15, 1, 1, '1234456789', '1111111', 'โคอาล่า', '0000-00-00', '0000-00-00', 'aaa'),
(16, 1, 1, '1234456789', '111111', 'โคอาล่า', '0000-00-00', '0000-00-00', '11'),
(17, 16, 1, '1234456789', '1111111', 'โคอาล่า', '0000-00-00', '0000-00-00', 'อนุมัติ'),
(18, 17, 1, '1234456789', '111111', 'โคอาล่า', '0000-00-00', '0000-00-00', 'ไม่อนุมัติ'),
(19, 18, 1, '1234456789', '111111', 'โคอาล่า', '0000-00-00', '0000-00-00', 'ไม่อนุมัติ'),
(20, 19, 1, 'b6020552004', '1002003000', 'โน้ตบุค', '2020-03-25', '2020-03-26', 'อนุมัติ'),
(21, 20, 1, 'b6020552004', '3001002000', 'แผ่นลงไดร์เวอร์', '2020-03-07', '2020-03-07', 'อนุมัติ'),
(22, 21, 1, 'b6020552004', '1002003000', 'โน้ตบุค', '2020-03-26', '2020-03-26', 'ไม่อนุมัติ'),
(23, 24, 1, 'b6020552004', '3001002000', 'แผ่นลงไดร์เวอร์', '2020-03-26', '2020-03-26', 'อนุมัติ'),
(24, 25, 1, 'b6020552004', '3001002000', 'แผ่นลงไดร์เวอร์', '2020-03-26', '2020-03-26', 'อนุมัติ');

-- --------------------------------------------------------

--
-- Table structure for table `usermember`
--

CREATE TABLE `usermember` (
  `UserCode` varchar(15) NOT NULL,
  `NameTitle` varchar(10) NOT NULL,
  `UserFNameEn` varchar(30) NOT NULL,
  `UserLNameEn` varchar(30) NOT NULL,
  `UserFNameTh` varchar(30) NOT NULL,
  `UserLNameTh` varchar(30) NOT NULL,
  `UserEmail` varchar(40) NOT NULL,
  `UserGender` varchar(10) NOT NULL,
  `DepartmentCode` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `usermember`
--

INSERT INTO `usermember` (`UserCode`, `NameTitle`, `UserFNameEn`, `UserLNameEn`, `UserFNameTh`, `UserLNameTh`, `UserEmail`, `UserGender`, `DepartmentCode`) VALUES
('b6020552004', 'Mr./นาย', 'Worrasak', 'Khammuang', 'วรศักดิ์', 'คำเหมือง', 'Worrasak.k@ku.th', 'Male', 'E29');

-- --------------------------------------------------------

--
-- Stand-in structure for view `view1`
-- (See below for the actual view)
--
CREATE TABLE `view1` (
`EquipmentID` varchar(30)
,`EquipmentName` varchar(30)
,`EquipmentStatus` varchar(30)
,`EquipmentINCartID` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view2`
-- (See below for the actual view)
--
CREATE TABLE `view2` (
`ApproveEquipmentID` int(11)
,`UserCode` varchar(15)
,`EquipmentID` varchar(30)
,`EquipmentName` varchar(30)
,`EquipmentStatus` varchar(30)
);

-- --------------------------------------------------------

--
-- Structure for view `followequipment`
--
DROP TABLE IF EXISTS `followequipment`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `followequipment`  AS  select `equipment`.`EquipmentID` AS `EquipmentID`,`equipment`.`EquipmentName` AS `EquipmentName`,`approveequipment`.`UserCode` AS `UserCode`,`equipment`.`EquipmentStatus` AS `EquipmentStatus`,`approveequipment`.`DateBorrow` AS `DateBorrow`,`approveequipment`.`DateReturn` AS `DateReturn` from (`equipment` join `approveequipment`) where `equipment`.`EquipmentID` = `approveequipment`.`EquipmentID` ;

-- --------------------------------------------------------

--
-- Structure for view `view1`
--
DROP TABLE IF EXISTS `view1`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view1`  AS  select `equipment`.`EquipmentID` AS `EquipmentID`,`equipment`.`EquipmentName` AS `EquipmentName`,`equipment`.`EquipmentStatus` AS `EquipmentStatus`,`equipmentincart`.`EquipmentINCartID` AS `EquipmentINCartID` from (`equipment` join `equipmentincart`) where `equipment`.`EquipmentID` = `equipmentincart`.`EquipmentID` ;

-- --------------------------------------------------------

--
-- Structure for view `view2`
--
DROP TABLE IF EXISTS `view2`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view2`  AS  select `approveequipment`.`ApproveEquipmentID` AS `ApproveEquipmentID`,`approveequipment`.`UserCode` AS `UserCode`,`equipment`.`EquipmentID` AS `EquipmentID`,`equipment`.`EquipmentName` AS `EquipmentName`,`equipment`.`EquipmentStatus` AS `EquipmentStatus` from (`approveequipment` join `equipment`) where `approveequipment`.`EquipmentID` = `equipment`.`EquipmentID` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advisor`
--
ALTER TABLE `advisor`
  ADD PRIMARY KEY (`AdvisorID`);

--
-- Indexes for table `approveequipment`
--
ALTER TABLE `approveequipment`
  ADD PRIMARY KEY (`ApproveEquipmentID`),
  ADD KEY `TypeID` (`TypeID`),
  ADD KEY `UserCode` (`UserCode`),
  ADD KEY `AdvisorID` (`AdvisorID`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`DepartmentCode`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`EquipmentID`),
  ADD KEY `TypeID` (`TypeID`);

--
-- Indexes for table `equipmentincart`
--
ALTER TABLE `equipmentincart`
  ADD PRIMARY KEY (`EquipmentINCartID`),
  ADD KEY `EquipmentID` (`EquipmentID`),
  ADD KEY `TypeID` (`TypeID`),
  ADD KEY `UserCode` (`UserCode`),
  ADD KEY `AdvisorID` (`AdvisorID`);

--
-- Indexes for table `equipmenttype`
--
ALTER TABLE `equipmenttype`
  ADD PRIMARY KEY (`TypeID`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `personneleq`
--
ALTER TABLE `personneleq`
  ADD PRIMARY KEY (`PersonnelEqID`),
  ADD KEY `EquipmentID` (`EquipmentID`);

--
-- Indexes for table `statusreserve`
--
ALTER TABLE `statusreserve`
  ADD PRIMARY KEY (`StatusReserveID`),
  ADD KEY `EquipmentID` (`EquipmentID`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`TeacherID`);

--
-- Indexes for table `teacherapp`
--
ALTER TABLE `teacherapp`
  ADD PRIMARY KEY (`TeacherAppID`),
  ADD KEY `ApproveEqID` (`ApproveEqID`),
  ADD KEY `Teacher` (`TeacherID`);

--
-- Indexes for table `usermember`
--
ALTER TABLE `usermember`
  ADD PRIMARY KEY (`UserCode`),
  ADD KEY `DepartmentCode` (`DepartmentCode`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advisor`
--
ALTER TABLE `advisor`
  MODIFY `AdvisorID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `approveequipment`
--
ALTER TABLE `approveequipment`
  MODIFY `ApproveEquipmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `equipmentincart`
--
ALTER TABLE `equipmentincart`
  MODIFY `EquipmentINCartID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=141;

--
-- AUTO_INCREMENT for table `personneleq`
--
ALTER TABLE `personneleq`
  MODIFY `PersonnelEqID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `statusreserve`
--
ALTER TABLE `statusreserve`
  MODIFY `StatusReserveID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `TeacherID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `teacherapp`
--
ALTER TABLE `teacherapp`
  MODIFY `TeacherAppID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `approveequipment`
--
ALTER TABLE `approveequipment`
  ADD CONSTRAINT `approveequipment_ibfk_2` FOREIGN KEY (`TypeID`) REFERENCES `equipmenttype` (`TypeID`),
  ADD CONSTRAINT `approveequipment_ibfk_3` FOREIGN KEY (`UserCode`) REFERENCES `usermember` (`UserCode`),
  ADD CONSTRAINT `approveequipment_ibfk_4` FOREIGN KEY (`AdvisorID`) REFERENCES `advisor` (`AdvisorID`);

--
-- Constraints for table `equipment`
--
ALTER TABLE `equipment`
  ADD CONSTRAINT `equipment_ibfk_1` FOREIGN KEY (`TypeID`) REFERENCES `equipmenttype` (`TypeID`);

--
-- Constraints for table `equipmentincart`
--
ALTER TABLE `equipmentincart`
  ADD CONSTRAINT `equipmentincart_ibfk_2` FOREIGN KEY (`TypeID`) REFERENCES `equipmenttype` (`TypeID`),
  ADD CONSTRAINT `equipmentincart_ibfk_3` FOREIGN KEY (`UserCode`) REFERENCES `usermember` (`UserCode`),
  ADD CONSTRAINT `equipmentincart_ibfk_4` FOREIGN KEY (`AdvisorID`) REFERENCES `advisor` (`AdvisorID`),
  ADD CONSTRAINT `equipmentincart_ibfk_5` FOREIGN KEY (`EquipmentID`) REFERENCES `equipment` (`EquipmentID`);

--
-- Constraints for table `personneleq`
--
ALTER TABLE `personneleq`
  ADD CONSTRAINT `personneleq_ibfk_1` FOREIGN KEY (`EquipmentID`) REFERENCES `equipment` (`EquipmentID`);

--
-- Constraints for table `statusreserve`
--
ALTER TABLE `statusreserve`
  ADD CONSTRAINT `statusreserve_ibfk_1` FOREIGN KEY (`EquipmentID`) REFERENCES `equipment` (`EquipmentID`);

--
-- Constraints for table `teacherapp`
--
ALTER TABLE `teacherapp`
  ADD CONSTRAINT `teacherapp_ibfk_2` FOREIGN KEY (`TeacherID`) REFERENCES `teacher` (`TeacherID`);

--
-- Constraints for table `usermember`
--
ALTER TABLE `usermember`
  ADD CONSTRAINT `usermember_ibfk_1` FOREIGN KEY (`UserCode`) REFERENCES `login` (`username`),
  ADD CONSTRAINT `usermember_ibfk_2` FOREIGN KEY (`DepartmentCode`) REFERENCES `department` (`DepartmentCode`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
