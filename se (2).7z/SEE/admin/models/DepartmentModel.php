<?php 
class Department{
	public $DepartmentCode,$DepartmentName;
	public function Department($DepartmentCode,$DepartmentName)
	{
		$this->DepartmentCode = $DepartmentCode;
		$this->DepartmentName = $DepartmentName;
		
	}

	public static function get($id)
{
  require("connection_connect.php");
  $sql = "select *from Department where DepartmentCode='$id'";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $DepartmentCode=$my_row['DepartmentCode$DepartmentCode'];
  $DepartmentName=$my_row['DepartmentName'];
 
  require("connection_close.php");

  return new Department($DepartmentCode,$DepartmentName);
}
	public static function getAll()
	{
		$DepartmentList=[];
		require("connection_connect.php");
		$sql="select * from Department";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
			$DepartmentCode=$my_row['DepartmentCode'];
			$DepartmentName=$my_row['DepartmentName'];
			
			$DepartmentList[]=new Department($DepartmentCode,$DepartmentName);
		}
		require("connection_close.php");
		return $DepartmentList;
		
		
	}
	public static function search($key)
	{
		$DepartmentList=[];
		require_once("connection_connect.php");
		$sql="select *from Departments
		where (DepartmentCode$DepartmentCode like'%$key%' or DepartmentName like'%$key%')";
		$result=$conn->query($sql);
		while ($my_row=$result->fetch_assoc())	
		{
			$DepartmentCode=$my_row['DepartmentCode$DepartmentCode'];
			$DepartmentName=$my_row['DepartmentName'];
			
			$DepartmentList[]=new Department($DepartmentCode,$DepartmentName);
		}
		require("connection_close.php");
		return $DepartmentList;

	}
}?>