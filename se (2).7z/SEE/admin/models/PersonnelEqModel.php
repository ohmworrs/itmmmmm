<?php 
class PersonnelEq{
	public $PersonnelEqID,$PersonnelName,$EquipmentID,$EquipmentName,$DateBorrow,$DateReturn;
	public function PersonnelEq($PersonnelEqID,$PersonnelName,$EquipmentID,$EquipmentName,$DateBorrow,$DateReturn)
	{
        $this->PersonnelEqID = $PersonnelEqID;
        $this->PersonnelName = $PersonnelName;
        $this->EquipmentID = $EquipmentID;
		$this->EquipmentName = $EquipmentName;
		$this->DateBorrow = $DateBorrow;
		$this->DateReturn = $DateReturn;
	}

	public static function get($Code)
{
  require("connection_connect.php");
  
  $sql = "select *from PersonnelEq where PersonnelEqID='$Code'";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $PersonnelEqID=$my_row['PersonnelEqID'];
  $PersonnelName=$my_row['PersonnelName'];
  $EquipmentID=$my_row['EquipmentID'];
  $EquipmentName=$my_row['EquipmentName'];
  $DateBorrow=$my_row['DateBorrow'];
  $DateReturn=$my_row['DateReturn'];
  require("connection_close.php");

  return new PersonnelEq($PersonnelEqID,$PersonnelName,$EquipmentID,$EquipmentName,$DateBorrow,$DateReturn);
}
	public static function getAll()
	{
		$PersonnelEqList=[];
		require("connection_connect.php");
		$sql="select * from PersonnelEq";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
            $PersonnelEqID=$my_row['PersonnelEqID'];
            $PersonnelName=$my_row['PersonnelName'];
            $EquipmentID=$my_row['EquipmentID'];
            $EquipmentName=$my_row['EquipmentName'];
            $DateBorrow=$my_row['DateBorrow'];
            $DateReturn=$my_row['DateReturn'];
			$PersonnelEqList[]=new PersonnelEq($PersonnelEqID,$PersonnelName,$EquipmentID,$EquipmentName,$DateBorrow,$DateReturn);
		}
		require("connection_close.php");
		return $PersonnelEqList;
		
		
	}
	public static function search($key)
	{
		$PersonnelEqList=[];
		require("connection_connect.php");
		$sql="select *from PersonnelEq
		where (PersonnelEqID like'%$key%' or PersonnelName like'%$key%' or DateBorrow like'%$key%' or DateReturn like'%$key%' or EquipmentID like'%$key%' or EquipmentName like'%$key%')";
		$result=$conn->query($sql);
		while ($my_row=$result->fetch_assoc())	
		{
            $PersonnelEqID=$my_row['PersonnelEqID'];
            $PersonnelName=$my_row['PersonnelName'];
            $EquipmentID=$my_row['EquipmentID'];
            $EquipmentName=$my_row['EquipmentName'];
            $DateBorrow=$my_row['DateBorrow'];
            $DateReturn=$my_row['DateReturn'];
			$PersonnelEqList[]=new PersonnelEq($PersonnelEqID,$PersonnelName,$EquipmentID,$EquipmentName,$DateBorrow,$DateReturn);
		}
		require("connection_close.php");
		return $PersonnelEqList;

	}

	public static function add($PersonnelName,$EquipmentID,$EquipmentName,$DateBorrow,$DateReturn)
	{
		require("connection_connect.php");
		$sql="insert into PersonnelEq (PersonnelName,EquipmentID,EquipmentName,DateBorrow,DateReturn)
		values('$PersonnelName','$EquipmentID','$EquipmentName','$DateBorrow','$DateReturn')";
		$result=$conn->query($sql);
		
		require("connection_close.php");
		return "add success $result rows";
	}

	public static function update($PersonnelEqID,$PersonnelName,$EquipmentID,$EquipmentName,$DateBorrow,$DateReturn)
	{	
	
		require("connection_connect.php");
		$sql="UPDATE PersonnelEq SET PersonnelName = '$PersonnelName',DateBorrow = '$DateBorrow',DateReturn = '$DateReturn',PersonnelEqImage = '$PersonnelEqImage',TypeID = '$TypeID' WHERE PersonnelEqID = '$PersonnelEqID'";
		$result=$conn->query($sql);
		require("connection_close.php");
		return "update success $result row";
	}
	public static function delete($id)
	{
		require("connection_connect.php");
		$sql="Delete from PersonnelEq	 where PersonnelEqID='$id'";
		$result=$conn->query($sql);
		require("connection_close.php");
		return "delete success $result row";
	}
}?>