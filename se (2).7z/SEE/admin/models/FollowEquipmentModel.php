<?php 
class FollowEquipment{
	public $EquipmentID,$EquipmentName,$UserCode,$EquipmentStatus,$DateBorrow,$DateReturn;
	public function FollowEquipment($EquipmentID,$EquipmentName,$UserCode,$EquipmentStatus,$DateBorrow,$DateReturn)
	{
		$this->EquipmentID = $EquipmentID;
		$this->EquipmentName = $EquipmentName;
		$this->UserCode = $UserCode;
		$this->EquipmentStatus = $EquipmentStatus;
		$this->DateBorrow = $DateBorrow;
		$this->DateReturn = $DateReturn;
	}

	public static function get($Code)
{
  require("connection_connect.php");
  
  $sql = "select *from FollowEquipment where EquipmentID='$Code'";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $EquipmentID=$my_row['EquipmentID'];
  $EquipmentName=$my_row['EquipmentName'];
  $UserCode=$my_row['UserCode'];
  $EquipmentStatus=$my_row['EquipmentStatus'];
  $DateBorrow=$my_row['DateBorrow'];
  $DateReturn=$my_row['DateReturn'];
  require("connection_close.php");

  return new FollowEquipment($EquipmentID,$EquipmentName,$UserCode,$EquipmentStatus,$DateBorrow,$DateReturn);
}
	public static function getAll()
	{
		$FollowEquipmentList=[];
		require("connection_connect.php");
		$sql="select * from FollowEquipment";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
			$EquipmentID=$my_row['EquipmentID'];
			$EquipmentName=$my_row['EquipmentName'];
			$UserCode=$my_row['UserCode'];
			$EquipmentStatus=$my_row['EquipmentStatus'];
			$DateBorrow=$my_row['DateBorrow'];
			$DateReturn=$my_row['DateReturn'];
			$FollowEquipmentList[]=new FollowEquipment($EquipmentID,$EquipmentName,$UserCode,$EquipmentStatus,$DateBorrow,$DateReturn);
		}
		require("connection_close.php");
		return $FollowEquipmentList;
		
		
	}
	public static function search($key)
	{
		$FollowEquipmentList=[];
		require_once("connection_connect.php");
		$sql="select *from FollowEquipmentshoww
		where (EquipmentID like'%$key%' or EquipmentName like'%$key%' or UserCode like'%$key%' or EquipmentStatus like'%$key%' or DateBorrow like'%$key%' or DateReturn like'%$key%')";
		$result=$conn->query($sql);
		while ($my_row=$result->fetch_assoc())	
		{
			$EquipmentID=$my_row['EquipmentID'];
			$EquipmentName=$my_row['EquipmentName'];
			$UserCode=$my_row['UserCode'];
			$EquipmentStatus=$my_row['EquipmentStatus'];
			$DateBorrow=$my_row['DateBorrow'];
			$DateReturn=$my_row['DateReturn'];
			$FollowEquipmentList[]=new FollowEquipment($EquipmentID,$EquipmentName,$UserCode,$EquipmentStatus,$DateBorrow,$DateReturn);
		}
		require("connection_close.php");
		return $FollowEquipmentList;

	}
}?>