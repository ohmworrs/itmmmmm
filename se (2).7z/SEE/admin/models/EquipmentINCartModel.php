<?php 
class EquipmentINCart{
	public $EquipmentINCartID,$UserCode,$EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentImage,$TypeID,$DateBorrow,$DateReturn,$Reason,$AdvisorID;
	public function EquipmentINCart($EquipmentINCartID,$UserCode,$EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentImage,$TypeID,$DateBorrow,$DateReturn,$Reason,$AdvisorID)
	{
        $this->EquipmentINCartID = $EquipmentINCartID;
        $this->UserCode = $UserCode;
		$this->EquipmentID = $EquipmentID;
		$this->EquipmentName = $EquipmentName;
		$this->EquipmentDetail = $EquipmentDetail;
        $this->EquipmentImage = $EquipmentImage;
		$this->TypeID = $TypeID;
		$this->DateBorrow = $DateBorrow;
		$this->DateReturn = $DateReturn;
		$this->Reason = $Reason;
		$this->AdvisorID = $AdvisorID;
		
	}

	public static function get($Code)
{
  require("connection_connect.php");
  
  $sql = "select *from EquipmentINCart where EquipmentINCartID='$Code'";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $EquipmentINCartID=$my_row['EquipmentINCartID'];
  $UserCode=$my_row['UserCode'];
  $EquipmentID=$my_row['EquipmentID'];
  $EquipmentName=$my_row['EquipmentName'];
  $EquipmentDetail=$my_row['EquipmentDetail'];
  $EquipmentImage=$my_row['EquipmentImage'];
  $TypeID=$my_row['TypeID'];
  $DateBorrow=$my_row['DateBorrow'];
  $DateReturn=$my_row['DateReturn'];
  $Reason=$my_row['Reason'];
  $AdvisorID=$my_row['AdvisorID'];
  require("connection_close.php");

  return new EquipmentINCart($EquipmentINCartID,$UserCode,$EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentImage,$TypeID,$DateBorrow,$DateReturn,$Reason,$AdvisorID);
}
	public static function getAll()
	{
		$EquipmentINCartList=[];
		require("connection_connect.php");
		$sql="select * from EquipmentINCart";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
            $EquipmentINCartID=$my_row['EquipmentINCartID'];
            $UserCode=$my_row['UserCode'];
			$EquipmentID=$my_row['EquipmentID'];
			$EquipmentName=$my_row['EquipmentName'];
			$EquipmentDetail=$my_row['EquipmentDetail'];
			
            $EquipmentImage=$my_row['EquipmentImage'];
			$TypeID=$my_row['TypeID'];
			$DateBorrow=$my_row['DateBorrow'];
			$DateReturn=$my_row['DateReturn'];
			$Reason=$my_row['Reason'];
			$AdvisorID=$my_row['AdvisorID'];
			$EquipmentINCartList[]=new EquipmentINCart($EquipmentINCartID,$UserCode,$EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentImage,$TypeID,$DateBorrow,$DateReturn,$Reason,$AdvisorID);
		}
		require("connection_close.php");
		return $EquipmentINCartList;
		
		
	}
	public static function search($key)
	{
		$EquipmentINCartList=[];
		require_once("connection_connect.php");
		$sql="select *from EquipmentINCartshoww
		where (EquipmentINCartID like'%$key%' or EquipmentID like'%$key%' or EquipmentName like'%$key%' or EquipmentDetail like'%$key%' or EquipmentStatus like'%$key%' or 
		EquipmentImage like'%$key%' or TypeID like'%$Key%' or DateBorrow like'%$Key%' or DateBorrow like'%$Key%' or DateReturn like'%$Key%' or Reason like'%$Key%' or AdvisorID like'%$Key%' )";
		$result=$conn->query($sql);
		while ($my_row=$result->fetch_assoc())	
		{
            $EquipmentINCartID=$my_row['EquipmentINCartID'];
            $UserCode=$my_row['UserCode'];
			$EquipmentID=$my_row['EquipmentID'];
			$EquipmentName=$my_row['EquipmentName'];
			$EquipmentDetail=$my_row['EquipmentDetail'];
            $EquipmentImage=$my_row['EquipmentImage'];
			$TypeID=$my_row['TypeID'];
			$DateBorrow=$my_row['DateBorrow'];
			$DateReturn=$my_row['DateReturn'];
			$Reason=$my_row['Reason'];
			$AdvisorID=$my_row['AdvisorID'];
			$EquipmentINCartList[]=new EquipmentINCart($EquipmentINCartID,$UserCode,$EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentImage,$TypeID,$DateBorrow,$DateReturn,$Reason,$AdvisorID);
		}
		require("connection_close.php");
		return $EquipmentINCartList;

	}
	
	public static function add($UserCode,$EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentImage,$TypeID,$DateBorrow,$DateReturn,$Reason,$AdvisorID)
	{
		require("connection_connect.php");

    	$sql = "insert into EquipmentINCart(UserCode,EquipmentID,EquipmentName,EquipmentDetail,EquipmentImage,TypeID,DateBorrow,DateReturn,Reason,AdvisorID)
    	values ('$UserCode','$EquipmentID','$EquipmentName','$EquipmentDetail','$EquipmentImage','$TypeID','$DateBorrow','$DateReturn','$Reason','$AdvisorID')";
		$result=$conn->query($sql);
	
		require("connection_close.php");
		return "add success $result rows";
	}

	public static function delete($id)
{
	require("connection_connect.php");
	

	$sql="Delete from EquipmentINCart where EquipmentINCartID='$id'";
	$result=$conn->query($sql);

	
	require("connection_close.php");
	return "delete success $result row";
}

}?>