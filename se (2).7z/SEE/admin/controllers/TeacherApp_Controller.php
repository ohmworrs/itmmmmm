<?php 
class TeacherAppController
{
	public function index()
	{
		$TeacherAppList=TeacherApp::getAll();
		require_once('views/TeacherApp/index_teacherapp.php');
    }
    
    public function newTeacherApp ()
    {
		
		$id=$_GET['ApproveEquipmentID'];
		$ApproveEquipment = ApproveEquipment::get($id); 
		$ApproveEquipmentList = ApproveEquipment::getAll();
		$TeacherList=Teacher::getAll();
       
      
        require_once('views/TeacherApp/newTeacherApp.php');

    }

    public function addTeacherApp()
	{
		$ApproveEqID=$_GET['ApproveEqID'];
		$TeacherID=$_GET['TeacherID'];
		$UserCode=$_GET['UserCode'];
		$EquipmentID=$_GET['EquipmentID'];
		$EquipmentName=$_GET['EquipmentName'];
		$DateBorrow=$_GET['DateBorrow'];
		$DateReturn=$_GET['DateReturn'];
		$StatusReserve = $_GET['StatusReserve'];

		TeacherApp::add($ApproveEqID,$TeacherID,$UserCode,$EquipmentID,$EquipmentName,$DateBorrow,$DateReturn,$StatusReserve);
		TeacherAppController::index();
	
	}
	public function deleteConfirm()
	{
		$TeacherAppID=$_GET['TeacherAppID'];
		$TeacherApp=TeacherApp::get($TeacherAppID);
		require_once('views/TeacherApp/deleteConfirm.php');
	}
	public function delete()
	{
			$TeacherAppID=$_GET['TeacherAppID'];
			TeacherApp::delete($TeacherAppID);
			TeacherAppController::index();
	}

	public function search()
	{
		$key=$_GET['key'];
		$TeacherAppList=TeacherApp::search($key);
		require_once('views/TeacherApp/index_teacherapp.php');
	}


}?>