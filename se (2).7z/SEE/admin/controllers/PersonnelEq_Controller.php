<?php 
class PersonnelEqController
{
	public function index()
	{
		$PersonnelEqList=PersonnelEq::getAll();
		require_once('views/PersonnelEq/index_personneleq.php');
    }
    
    public function newPersonnelEq ()
    {
		
		$Code=$_GET['EquipmentID'];
		$Equipment = Equipment::get($Code ); 
		
        require_once('views/PersonnelEq/newPersonnelEq.php');

    }

    public function addPersonnelEq()
	{
        $PersonnelName=$_GET['PersonnelName'];
        $EquipmentID=$_GET['EquipmentID'];
		$EquipmentName=$_GET['EquipmentName'];
		$DateBorrow=$_GET['DateBorrow'];
		$DateReturn=$_GET['DateReturn'];


		PersonnelEq::add($PersonnelName,$EquipmentID,$EquipmentName,$DateBorrow,$DateReturn);
		PersonnelEqController::index();
	
	}
	public function deleteConfirm()
	{
		$PersonnelEqID=$_GET['PersonnelEqID'];
		$PersonnelEq=PersonnelEq::get($PersonnelEqID);
		require_once('views/PersonnelEq/deleteConfirm.php');
	}
	public function delete()
	{
			$PersonnelEqID=$_GET['PersonnelEqID'];
			PersonnelEq::delete($PersonnelEqID);
			PersonnelEqController::index();
	}

	public function search()
	{
		$key=$_GET['key'];
		$PersonnelEqList=PersonnelEq::search($key);
		require_once('views/PersonnelEq/index_personneleq.php');
	}


}?>