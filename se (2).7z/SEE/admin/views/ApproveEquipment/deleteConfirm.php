<?php echo "<br>Are you sure to delete this <br>
            <br>$ApproveEquipment->ApproveEquipmentID  <br>";  ?>
<form method="get" action="">"
    <input type="hidden" name="controller" value="ApproveEquipment"/>
    <input type="hidden" name="ApproveEquipmentID" value="<?php echo $ApproveEquipment->ApproveEquipmentID; ?>" />
    <button type="submit" name="action" value="index">Back</button>
    <button type="submit" name="action" value="delete">Delete</button>
</form>
