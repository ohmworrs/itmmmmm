<form method="get" action="">
<label> TeacherID<input type="int" name="TeacherID"
value="<?php echo $Teacher->TeacherID; ?>" /> </label><br>
<label>TeacherName <input type="text" name="TeacherName" 
value="<?php echo $Teacher->TeacherName; ?>"/> </label><br>
<label>Position <input type="text" name="Position" 
value="<?php echo $Teacher->Position; ?>"/> </label><br>

<input type="hidden" name="controller" value="Teacher"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="update"> Save</button>

</form>
