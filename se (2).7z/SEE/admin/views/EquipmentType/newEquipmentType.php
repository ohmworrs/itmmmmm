
<form method="get" action="">

<label>TypeID <input type="text" name="TypeID" /> </label><br>
<label>TypeName <input type="text" name="TypeName" /> </label><br>

<input type="hidden" name="controller" value="EquipmentType"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addEquipmentType"> Save</button>

</form>



