<?php echo "<br>Are you sure to delete this <br>
            <br>$EquipmentINCart->EquipmentINCartID  <br>";  ?>
<form method="get" action="">"
    <input type="hidden" name="controller" value="EquipmentINCart"/>
    <input type="hidden" name="EquipmentINCartID" value="<?php echo $EquipmentINCart->EquipmentINCartID; ?>" />
    <button type="submit" name="action" value="index">Back</button>
    <button type="submit" name="action" value="delete">Delete</button>
</form>
