
<html>
<head>
  				
	<title></title>
</head>
<body>

</body>
</html>

<?php

//error_reporting (E_ALL ^ E_NOTICE);	

if (isset($_GET['controller'])&&isset($_GET['action']))
{
	$controller = $_GET['controller'];
	$action = $_GET['action'];
}
else 
{
	$controller = 'pages';
	$action = 'home';
}?>
<html>

<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" integrity="sha384-v8BU367qNbs/aIZIxuivaU55N5GPF89WBerHoGA4QTcbUjYiLQtKdrfXnqAcXyTv" crossorigin="anonymous">
</head>
<style>

body  {
	width:100%;
  background-image: url("#") ;
  background-repeat: no-repeat;
  background-attachment: fixed;
	background-size: cover;
	background-position: center;
	
}
.table{
	width: 100%;
	border-collapse: collapse;	
		}
.table td,.table th{
	padding: 12px 15px;
	border: 1px solid #ddd;
	text-align: center;
}
@media(max-width: 500px){
	.table thead{
		display: none;
	}
	.table, .table tbody, .table tr, .table td{
		display: block;
		width: 100%;
	}
	.table tr{
		margin-bottom:15px;
	}
	.table td{
		text-align: right;
		padding-left: 50%;
		text-align: right;
		position: relative;
	}
	.table td::before{
		content: attr(data-lable);
		position: absolute;
		left: 0;
		width: 50%;
		padding-left:15px;
		font-size:15px;
		font-weight: bold;
		text-align: left;
	}
}
</style>	
<?php session_start();  
require_once("connection_connect.php");

  $user_name = $_SESSION['username'];
  $name = $_SESSION['name'];
  $level = $_SESSION['level'];

 	if($level!='teacher'){
    Header("Location: ../loginform.php");  
  }  
?>
<script src="js/jquery-3.3.1.min.js" type="text/javascript"></script>
	<script src="js/popper.min.js" type="text/javascript"></script>
	<script src="js/bootstrap-4.3.1.js" type="text/javascript"></script>
<body>
<nav class="shadow navbar navbar-expand-lg navbar-dark bg-dark" style="background-color: #e2d224;"> 
  	  <a class="navbar-brand">
    <img src="https://upload.wikimedia.org/wikipedia/commons/9/97/KU_Logo.png" width="80" alt="">
		 ยืม-คืนอุปกรณ์
  </a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent1" aria-controls="navbarSupportedContent1" aria-expanded="false" aria-label="Toggle navigation"> 
			<span class="navbar-toggler-icon"></span> 
		</button>
 			<div class="collapse navbar-collapse" id="navbarSupportedContent1">
    			<ul class="navbar-nav mr-auto">
      				<li class="nav-item"> 
					  <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
					</li>
     				<li class="nav-item"> 
					  <a class="nav-link" href="?controller=Advisor&action=index">อาจารย์ที่ปรึกษาโครงการ</a> 
					</li>
     				<li class="nav-item "> 
					  <a class="nav-link" href="?controller=Teacher&action=index">อาจารย์ที่ปรึกษา</a>
					</li>
					<li class="nav-item "> 
					  <a class="nav-link" href="?controller=TeacherApp&action=index">ติดตามสถานะการจอง</a>
					</li>
					<li class="nav-item "> 
					  <a class="nav-link" href="?controller=EquipmentType&action=index">หมวดหมู่อุปกรณ์</a>
					</li>
					<li class="nav-item "> 
					  <a class="nav-link" href="?controller=Equipment&action=index">อุปกรณ์</a>
					</li>
				
					<li class="nav-item "> 
					  <a class="nav-link" href="?controller=ApproveEquipment&action=index">คำร้องขอ</a>
					</li>
					<li class="nav-item "> 
					  <a class="nav-link" href="?controller=TeacherApp&action=index">เช็คสถานะ</a>
					</li>
					<li class="nav-item "> 
					  <a class="nav-link" href="?controller=PersonnelEq&action=index">การยืมของบุคลากร</a>
					</li>
				
    			</ul>
    			<form class="form-inline my-2 my-lg-0">
      			<a href="./logout.php" class="btn btn-danger" role="button">log out</a>
    			</form>
  			</div>
	</nav>
		<center>
	
	
				
			<br>
		
  

			<br>
</body>	
	 
	 	<?php require_once("routes.php");?> 

	
</div>
	

</html>	