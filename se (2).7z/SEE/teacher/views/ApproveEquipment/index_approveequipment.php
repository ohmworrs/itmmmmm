<html>
	<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" integrity="sha384-v8BU367qNbs/aIZIxuivaU55N5GPF89WBerHoGA4QTcbUjYiLQtKdrfXnqAcXyTv" crossorigin="anonymous"> 
	</head>

	<body>
		<div class="container">
           
			<div><br></div>
			<table class="table table-striped table-dark  table-responsive"> 
  			<thead class="thead-dark">
   				 <tr align ='center' >
                    <th scope="col">ApproveEquipmentID</th>
                    <th scope="col">EquipmentINCartID</th>
                    <th scope="col">UserCode</th>
                    <th scope="col">EquipmentID</th>
                    <th scope="col">EquipmentName</th>
                    <th scope="col">EquipmentDetail</th>
                    <th scope="col">EquipmentImage</th>
                    <th scope="col">TypeID</th>
                    <th scope="col">DateBorrow</th>
                    <th scope="col">DateReturn</th>
					<th scope="col">Reason</th>
					<th scope="col">Advisor</th>
					<th scope="col">อนุมัติ</th>
					<th scope="col">ไม่อนุมัติ</th>
    			</tr>
  			</thead></tr>
		 <tbody style="">
<?php 
foreach($ApproveEquipmentList as $ApproveEquipment)
{
    echo "<tr align ='center'>   
                 <td data - label = 'ApproveEquipmentID'>$ApproveEquipment->ApproveEquipmentID</td>
                 <td data - label = 'EquipmentINCartID'>$ApproveEquipment->EquipmentINCartID</td>
                 <td data - label = 'UserCode'>$ApproveEquipment->UserCode</td>
                 <td data - label = 'EquipmentID'>$ApproveEquipment->EquipmentID</td>
                 <td data - label = 'EquipmentName'>$ApproveEquipment->EquipmentName</td>
                 <td data - label = 'EquipmentDetail'>$ApproveEquipment->EquipmentDetail </td>
                 <td data - label = 'EquipmentImage'>$ApproveEquipment->EquipmentImage </td>
                 <td data - label = 'TypeID'>$ApproveEquipment->TypeID</td>
                 <td data - label = 'DateBorrow'>$ApproveEquipment->DateBorrow</td>
				 <td data - label = 'DateReturn'>$ApproveEquipment->DateReturn</td>
				 <td data - label = 'Reason'>$ApproveEquipment->Reason</td>
				 <td data - label = 'Advisor'>$ApproveEquipment->AdvisorID</td>
            </tr>";     
}
echo "</table>"; 
?>
			 </tbody>
		</div>   
	</body>
</html>	




