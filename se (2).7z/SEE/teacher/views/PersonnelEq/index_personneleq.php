<html>
	<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" integrity="sha384-v8BU367qNbs/aIZIxuivaU55N5GPF89WBerHoGA4QTcbUjYiLQtKdrfXnqAcXyTv" crossorigin="anonymous"> 
	</head>

	<body>
	<link rel="stylesheet" href="node_modules\bootstrap\dist\js\bootstrap.min.js">
	<link rel="stylesheet" href="node_modules\jquery\dist\jquery.min.js">
	<link rel="stylesheet" href="node_modules\popper.js\dist\umd\popper.min.js">
		<div class="container">
            <form method="get" action="">
					<div class=" shadow input-group mb-3 " >
						<input type="text" name="key"class="form-control" placeholder="ค้นหา" aria-label="Recipient's username" aria-describedby="button-addon2">
						<input type="hidden" name="controller" value="PersonnelEq" class="form-control" placeholder="ค้นหา" aria-label="Recipient's username" aria-describedby="button-addon2">
						<div class=" input-group-append ">
							<button class="btn btn btn-secondary" type="submit" name="action" value="search" id="button-addon2">Search</button>
						</div>
					</div>
				</form>
			<div><br></div>
			<table class="table table-striped table-dark"> 
  			<thead class="thead-dark">
   				 <tr align ='center' >
                    <th scope="col">PersonnelEqID</th>
					<th scope="col">PersonnelName</th>  
					<th scope="col">EquipmentID</th>  
					<th scope="col">EquipmentName</th>
					<th scope="col">DateBorrow</th>  
					<th scope="col">DateReturn</th>   
    			</tr>
  			</thead></tr>
		 <tbody style="">
<?php 
foreach($PersonnelEqList as $PersonnelEq)
{
    echo "<tr align ='center'>   
                 <td data - label = 'PersonnelEqID'>$PersonnelEq->PersonnelEqID</td>
				 <td data - label = 'PersonnelName'>$PersonnelEq->PersonnelName</td>
				 <td data - label = 'EquipmentID'>$PersonnelEq->EquipmentID  </td>
				 <td data - label = 'EquipmentName'>$PersonnelEq->EquipmentName </td>
                 <td data - label = 'DateBorrow'>$PersonnelEq->DateBorrow</td>
                 <td data - label = 'DateReturn'>$PersonnelEq->DateReturn </td> </tr>";     }
echo "</table>"; 
?>
			 </tbody>
		</div>   
	</body>
</html>	
