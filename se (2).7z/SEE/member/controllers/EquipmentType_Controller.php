<?php 
class EquipmentTypeController
{
	public function index()
	{
		$EquipmentTypeList=EquipmentType::getAll();
		require_once('views/EquipmentType/index_equipmenttype.php');
	}

	public function search()
	{
		$key=$_GET['key'];
		$EquipmentTypeList=EquipmentType::search($key);
		require_once('views/EquipmentType/index_equipmenttype.php');
	}
}?>