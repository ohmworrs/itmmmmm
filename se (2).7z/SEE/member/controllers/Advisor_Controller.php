<?php 
class AdvisorController
{
	public function index()
	{
		$AdvisorList=Advisor::getAll();
		require_once('views/Advisor/index_advisor.php');
	}
	public function search()
	{
		$key=$_GET['key'];
		$AdvisorList=Advisor::search($key);
		require_once('views/Advisor/index_advisor.php');
	}
}?>