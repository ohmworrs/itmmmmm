<?php 
class EquipmentController
{
	public function index()
	{
		$EquipmentList=Equipment::getAll();
		require_once('views/Equipment/index_equipment.php');
	}
	public function search()
	{
		$key=$_GET['key'];
		$EquipmentList=Equipment::search($key);
		require_once('views/Equipment/index_equipment.php');
	}
}?>