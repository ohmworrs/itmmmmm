<?php 
class Advisor{
	public $AdvisorID,$AdvisorName;
	public function Advisor($AdvisorID,$AdvisorName)
	{
		$this->AdvisorID = $AdvisorID;
		$this->AdvisorName = $AdvisorName;
		
	}

	public static function get($id)
{
  require("connection_connect.php");
  $sql = "select *from Advisor where AdvisorID='$id'";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $AdvisorID=$my_row['AdvisorID$AdvisorID'];
  $AdvisorName=$my_row['AdvisorName'];
 
  require("connection_close.php");

  return new Advisor($AdvisorID,$AdvisorName);
}
	public static function getAll()
	{
		$AdvisorList=[];
		require("connection_connect.php");
		$sql="select * from Advisor";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
			$AdvisorID=$my_row['AdvisorID'];
			$AdvisorName=$my_row['AdvisorName'];
			
			$AdvisorList[]=new Advisor($AdvisorID,$AdvisorName);
		}
		require("connection_close.php");
		return $AdvisorList;
		
		
	}
	public static function search($key)
	{
		$AdvisorList=[];
		require("connection_connect.php");
		$sql="select *from Advisor
		where (AdvisorID like'%$key%' or AdvisorName like'%$key%')";
		$result=$conn->query($sql);
		while ($my_row=$result->fetch_assoc())	
		{
			$AdvisorID=$my_row['AdvisorID'];
			$AdvisorName=$my_row['AdvisorName'];
			
			$AdvisorList[]=new Advisor($AdvisorID,$AdvisorName);
		}
		require("connection_close.php");
		return $AdvisorList;

	}
}?>