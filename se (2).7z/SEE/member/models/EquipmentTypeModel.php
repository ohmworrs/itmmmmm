<?php 
class EquipmentType{
	public $TypeID,$TypeName;
	public function EquipmentType($TypeID,$TypeName)
	{
		$this->TypeID = $TypeID;
		$this->TypeName = $TypeName;
		
	}

	public static function get($id)
{
  require("connection_connect.php");
  $sql = "select *from EquipmentTypewhere TypeID='$id'";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $TypeID=$my_row['TypeID$TypeID'];
  $TypeName=$my_row['TypeName'];
 
  require("connection_close.php");

  return new EquipmentType($TypeID,$TypeName);
}
	public static function getAll()
	{
		$EquipmentTypeList=[];
		require("connection_connect.php");
		$sql="select * from EquipmentType";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
			$TypeID=$my_row['TypeID'];
			$TypeName=$my_row['TypeName'];
			
			$EquipmentTypeList[]=new EquipmentType($TypeID,$TypeName);
		}
		require("connection_close.php");
		return $EquipmentTypeList;
		
		
	}
	public static function search($key)
	{
		$EquipmentTypeList=[];
		require("connection_connect.php");
		$sql="select *from EquipmentType
		where (TypeID like'%$key%' or TypeName like'%$key%')";
		$result=$conn->query($sql);
		while ($my_row=$result->fetch_assoc())	
		{
			$TypeID=$my_row['TypeID'];
			$TypeName=$my_row['TypeName'];
			
			$EquipmentTypeList[]=new EquipmentType($TypeID,$TypeName);
		}
		require("connection_close.php");
		return $EquipmentTypeList;

	}
}?>