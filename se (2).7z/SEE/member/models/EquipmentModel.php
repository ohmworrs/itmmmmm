<?php 
class Equipment{
	public $EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentImage,$TypeID;
	public function Equipment($EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentImage,$TypeID)
	{
		$this->EquipmentID = $EquipmentID;
		$this->EquipmentName = $EquipmentName;
		$this->EquipmentDetail = $EquipmentDetail;
		$this->EquipmentStatus = $EquipmentStatus;
		$this->EquipmentImage = $EquipmentImage;
		$this->TypeID = $TypeID;
	}

	public static function get($Code)
{
  require("connection_connect.php");
  
  $sql = "select *from Equipment where EquipmentID='$Code'";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $EquipmentID=$my_row['EquipmentID'];
  $EquipmentName=$my_row['EquipmentName'];
  $EquipmentDetail=$my_row['EquipmentDetail'];
  $EquipmentStatus=$my_row['EquipmentStatus'];
  $EquipmentImage=$my_row['EquipmentImage'];
  $TypeID=$my_row['TypeID'];
  require("connection_close.php");

  return new Equipment($EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentImage,$TypeID);
}
	public static function getAll()
	{
		$EquipmentList=[];
		require("connection_connect.php");
		$sql="select * from Equipment";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
			$EquipmentID=$my_row['EquipmentID'];
			$EquipmentName=$my_row['EquipmentName'];
			$EquipmentDetail=$my_row['EquipmentDetail'];
			$EquipmentStatus=$my_row['EquipmentStatus'];
			$EquipmentImage=$my_row['EquipmentImage'];
			$TypeID=$my_row['TypeID'];
			$EquipmentList[]=new Equipment($EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentImage,$TypeID);
		}
		require("connection_close.php");
		return $EquipmentList;
		
		
	}
	public static function search($key)
	{
		$EquipmentList=[];
		require("connection_connect.php");
		$sql="select *from Equipment
		where (EquipmentID like'%$key%' or EquipmentName like'%$key%' or EquipmentDetail like'%$key%' or EquipmentStatus like'%$key%' or EquipmentImage like'%$key%' or TypeID like'%$key%')";
		$result=$conn->query($sql);
		while ($my_row=$result->fetch_assoc())	
		{
			$EquipmentID=$my_row['EquipmentID'];
			$EquipmentName=$my_row['EquipmentName'];
			$EquipmentDetail=$my_row['EquipmentDetail'];
			$EquipmentStatus=$my_row['EquipmentStatus'];
			$EquipmentImage=$my_row['EquipmentImage'];
			$TypeID=$my_row['TypeID'];
			$EquipmentList[]=new Equipment($EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentImage,$TypeID);
		}
		require("connection_close.php");
		return $EquipmentList;

	}
}?>