<html>
	<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" integrity="sha384-v8BU367qNbs/aIZIxuivaU55N5GPF89WBerHoGA4QTcbUjYiLQtKdrfXnqAcXyTv" crossorigin="anonymous"> 
	</head>

	<body>
	<link rel="stylesheet" href="node_modules\bootstrap\dist\js\bootstrap.min.js">
	<link rel="stylesheet" href="node_modules\jquery\dist\jquery.min.js">
	<link rel="stylesheet" href="node_modules\popper.js\dist\umd\popper.min.js">
		<div class="container">
           
			<div><br></div>
			<table class="table table-striped table-dark table-responsive"> 
  			<thead class="thead-dark">
   				 <tr align ='center' >
                    <th scope="col">EquipmentINCartID</th>
					<th scope="col">UserCode</th>  
					<th scope="col">EquipmentID</th>  
					<th scope="col">EquipmentName</th>  
					<th scope="col">EquipmentDetail</th>  
					<th scope="col">EquipmentImage</th>  
					<th scope="col">TypeID</th>  
					<th scope="col">DateBorrow</th>  
					<th scope="col">DateReturn</th>  
					<th scope="col">Reason</th>  
					<th scope="col">Advisor</th>  
					<th scope="col">Cancel</th>  
					<th scope="col">ร้องขอการอนุมัติ</th>    
    			</tr>
  			</thead></tr>
		 <tbody style="">
<?php 
foreach($EquipmentINCartList as $EquipmentINCart)
{
    echo "<tr align ='center'>   
                 <td data - label = 'EquipmentINCartID'>$EquipmentINCart->EquipmentINCartID</td>
                 <td data - label = 'UserCode'>$EquipmentINCart->UserCode</td>
                 <td data - label = 'EquipmentID'>$EquipmentINCart->EquipmentID </td>
                 <td data - label = 'EquipmentName'>$EquipmentINCart->EquipmentName</td>
                 <td data - label = 'EquipmentDetail'>$EquipmentINCart->EquipmentDetail </td>
                 <td data - label = 'EquipmentImage'>$EquipmentINCart->EquipmentImage</td>
                 <td data - label = 'TypeID'>$EquipmentINCart->TypeID</td>
                 <td data - label = 'DateBorrow'>$EquipmentINCart->DateBorrow</td>
                 <td data - label = 'DateReturn'>$EquipmentINCart->DateReturn</td>
				 <td data - label = 'Reason'>$EquipmentINCart->Reason</td>
				 <td data - label = 'Advisor'>$EquipmentINCart->AdvisorID </td>
				 <td><a href=?controller=UserReserve&action=deleteConfirm&UserID=$EquipmentINCart->EquipmentINCartID button type='button' class= 'btn btn-danger ' ><i class='fas fa-times-circle'></i>delete </a> </td>
                 <td><a href=?controller=UserReserve&action=updateForm&UserID=$EquipmentINCart->EquipmentINCartID button type='button' class= 'btn btn-primary ' ><i class='fas fa-arrow-alt-circle-down'></i> ขออนุมัติ </a></td> 
                 
            </tr>";     
}
echo "</table>"; 
?>
			 </tbody>
		</div>   
	</body>
</html>	
